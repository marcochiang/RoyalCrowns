/*
 * Menu.cpp
 *
 *  Created on: Nov 20, 2012
 *      Author: john
 */

#include "Menu.h"

Menu::Menu() {
	//public

	//protected

	//private



}

Menu::~Menu() {
	// TODO Auto-generated destructor stub
}
