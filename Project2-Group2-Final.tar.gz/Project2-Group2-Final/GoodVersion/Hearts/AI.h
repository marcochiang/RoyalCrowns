/*
 * AI.h
 *
 *  Created on: Oct 30, 2012
 *      Author: sireniti
 */
#include "Rules.h"


#ifndef AI_H_
#define AI_H_
#include "Player.h"
class AI{
public:

	AI();
	virtual ~AI();

	//functions
	void setPuppet(Player person);
	Card chooseTrickCard(theGauvin heartBeat);
	bool lowerThanAce(int firstCardNumber, int secondCardNumber);
	bool greaterThanAce(int firstCardNumber, int secondCardNumber);
	Card* choosePassCards();
	Card chooseTrickCardEasy(Rules &rules, theGauvin heartBeat);	//

	//variables
	Player *puppet;
};

#endif /* AI_H_ */
