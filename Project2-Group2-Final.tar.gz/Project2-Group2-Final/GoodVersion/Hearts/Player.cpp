#include "Player.h"
#include "structs.h"
#include <string>

Player::Player()
{
	playerNum = -1;
    playerName = "";
    score = 0;
   // cardPlayed = NULL; /*either delete this or come up with scheme for a null card*/
    numberOfTrickPileCards = 0;
    AIplaceHolder = 0;
}

Player::~Player()
{
    //dtor
}
void Player::setNumberOfTrickPileCards(int numOfCards){
	numberOfTrickPileCards = numOfCards;
}

//int Player::getNumberOfTrickPileCards(){
//	return numberOfTrickPileCards;
//}

void Player::setPlayerNumber(int x){
	playerNum = x;
}

int Player::getPlayerNumber(){
	return playerNum;
}

int Player::getNumberOfTrickPileCards(){
	return numberOfTrickPileCards;
}

void Player::incrementAIPlaceHolder(){
	AIplaceHolder++;
}

int Player::getAIplaceHolder(){
	return AIplaceHolder;
}

void Player::setAIplaceHolder(int newPlaceHolder){
	AIplaceHolder = newPlaceHolder;
}

//maybe something wrong with this function
void Player::populateHand(int index, Card card){
    playerHand[index]=card;
	//printf("card suit = %d", card.suit);
}

string Player::getName(){
    return playerName;
}

Card* Player::getHand(){
    return playerHand;
}

Card Player::playCard(Card card){
    int placeholder = 0;

    for(int i = 0; i<13; i++){
        if(playerHand[i].suit==card.suit && playerHand[i].cardNumber == card.cardNumber){
            placeholder = i;
        }
    }

    cardPlayed = playerHand[placeholder];
    //playerHand[placeholder] == NULL; /*come up with scheme for null card*/

    return cardPlayed;
}

Card Player::playCard(int cardNumber, int suit){
    int placeholder = 0;

    for(int i = 0; i<13; i++){
        if(playerHand[i].suit==suit && playerHand[i].cardNumber==cardNumber){
            placeholder = i;
        }
    }

    cardPlayed = playerHand[placeholder];
    //playerHand[placeholder] == NULL; /*come up with scheme for null card*/

    return cardPlayed;
}
//returns the array holding the player's chosen pass cards
Card* Player::getCardsPassed(){
	return cardsPassed;
}

void Player::setCardsPassed(int i, Card c){
	cardsPassed[i] = c;
}

Card Player::getCardPlayed(){
    return cardPlayed;
}

Card* Player::getTrickPile(){
    return trickPile;
}
void Player::setName(string name){
    playerName = name;
}
void Player::winTrickPile(Card* trick){
    for(int i = 1; i<5; i++){
        trickPile[numberOfTrickPileCards] = trick[i];
        numberOfTrickPileCards++;
    }
}

bool Player::hasHearts(){
	bool hasH = false;
	for(int i = 0; i < 13; i++){
		if(playerHand[i].suit == HEARTS) hasH = true;
	}
	return hasH;
}

bool Player::hasSpades(){
	bool hasS = false;
	for(int i = 0; i < 13; i++){
		if(playerHand[i].suit == SPADES) hasS = true;
	}
	return hasS;
}

bool Player::hasDiamonds(){
	bool hasD = false;
	for(int i = 0; i < 13; i++){
		if(playerHand[i].suit == DIAMONDS) hasD = true;
	}
	return hasD;
}

bool Player::hasClubs(){
	bool hasC = false;
	for(int i = 0; i < 13; i++){
		if(playerHand[i].suit == CLUBS) hasC = true;
	}
	return hasC;
}

bool Player::hasSuit(int suit){
	bool hasX = false;
	for(int i = 0; i < 13; i++){
		if(playerHand[i].suit == suit) hasX = true;
	}
	return hasX;
}

bool Player::isInTrickPile(int suit, int cardNumber){
	for(int i = 0; i<13; i++){
		if(playerHand[i].suit == suit && playerHand[i].cardNumber == cardNumber){
			return true;
		}
	}
	return false;
}

Card Player::findInTrickPile(int suit, int cardNumber){
	Card nullCard;
	for(int i = 0; i<13; i++){
		if(playerHand[i].suit == suit && playerHand[i].cardNumber == cardNumber){
			return playerHand[i];
		}
	}
	return nullCard;
}

void Player::setHand(int i, Card c){
	playerHand[i]=c;
}

void Player::setNullHandCard(int i){
	playerHand[i].suit = -1;
	playerHand[i].cardNumber = -1;
	playerHand[i].xPosition = -1;
	playerHand[i].yPosition = -1;
	playerHand[i].player = -1;
	playerHand[i].deckNumber = -1;
	playerHand[i].penaltyValue = 0;

}

void Player::setNullPassCard(int i){
	cardsPassed[i].suit = -1;
	cardsPassed[i].cardNumber = -1;
	cardsPassed[i].xPosition = -1;
	cardsPassed[i].yPosition = -1;
	cardsPassed[i].player = -1;
	cardsPassed[i].deckNumber = -1;
	cardsPassed[i].penaltyValue = 0;
}

void Player::setNullTrickPileCard(int i){
	trickPile[i].suit = -1;
	trickPile[i].cardNumber = -1;
	trickPile[i].xPosition = -1;
	trickPile[i].yPosition = -1;
	trickPile[i].player = -1;
	trickPile[i].deckNumber = -1;
	trickPile[i].penaltyValue = 0;
}

void Player::setPassArray(Card *array){
	for(int i = 0; i<3; i++){
		cardsPassed[i] = array[i];
	}
}
//TODO: look up sort algorithms for primitives
