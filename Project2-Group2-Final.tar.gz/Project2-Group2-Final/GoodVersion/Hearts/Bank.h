/*
 * Bank.h
 *
 *      Author: John Fuller
 */

#ifndef BANK_H_
#define BANK_H_
#include "display.h"

class Bank{

public:
	Bank();
	display gameDisplay;
	int bet;
	int bank;
	void getBet();
	void winBet();
	void lossBet();
};


#endif /* BANK_H_ */
