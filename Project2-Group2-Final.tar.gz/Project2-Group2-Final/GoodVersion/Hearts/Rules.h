/*
 * Rules.h
 *
 *  Created on: Oct 31, 2012
 *      Author: sireniti
 */
#include "Player.h"
#include "structs.h"

#ifndef RULES_H_
#define RULES_H_

class Rules {
public:
	Rules();
	virtual ~Rules();

	bool checkIfValidCard(Card &theCard, theGauvin &hb, Player &p0);
	//bool checkIfValidCard(Card , theGauvin, Player );
};

#endif /* RULES_H_ */
