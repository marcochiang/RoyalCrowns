/*
 * AI.cpp
 *
 *  Created on: Oct 30, 2012
 *      Author: sireniti
 */

#include "AI.h"
#include "Player.h"
#include "structs.h"
#include "Rules.h"

AI::AI() {
	//puppet = new Player();
}

AI::~AI() {
	// TODO Auto-generated destructor stub
}

void AI::setPuppet(Player person){
	puppet = &person;
}

bool AI::lowerThanAce(int firstCardNumber, int secondCardNumber){
	if(firstCardNumber == 1) firstCardNumber = 14;
	if(secondCardNumber == 1) secondCardNumber = 14;

	if(firstCardNumber < secondCardNumber)return true;
	else return false;
}

bool AI::greaterThanAce(int firstCardNumber, int secondCardNumber){
	if(firstCardNumber == ACE) firstCardNumber = 14;
	if(secondCardNumber == ACE) secondCardNumber = 14;

	if(firstCardNumber > secondCardNumber)return true;
	else return false;
	return true;
}

Card AI::chooseTrickCard(theGauvin heartBeat) {
	Card currentLow;
	currentLow.cardNumber = ACE;
	bool hasSuit = false;
	if (puppet->getPlayerNumber() == heartBeat.twoOfClubsOwner) {
		//return the two of clubs card
		if (puppet->isInTrickPile(CLUBS, 2)) {
			return (puppet->findInTrickPile(CLUBS, 2));
		}
	}
	else {
			//step through the hand and see if the hand contains the current suit
			for (int i = 0; i < 13; i++) {
				if (puppet->getHand()[i].suit == heartBeat.currentTrickSuit) {
					hasSuit = true;
				}
			}
			for(int i=0; i<13; i++){
				switch (heartBeat.currentTurnState) {
					case UNBROKENHEARTS:
						if (puppet->getPlayerNumber() == heartBeat.currentTrickOwner && puppet->getHand()[i].suit != HEARTS) {
							//return any card but hearts here that is in the current hand
						}
						else if(hasSuit) {
							if(puppet->getHand()[i].suit == heartBeat.currentTrickSuit) {
								//determine the lowest card in the current suit

								if(greaterThanAce(currentLow.cardNumber, puppet->getHand()[i].cardNumber)) {
									currentLow = puppet->getHand()[i];
								}
							}
						}
						else{
							//if doesn't have suit, choose the highest card of any suit
							//currentLow would become the highest valued cardNumber in this case
							if(heartBeat.currentTurnState == FIRSTHAND && puppet->getHand()[i].suit != HEARTS){
								if (!lowerThanAce(currentLow.cardNumber, puppet->getHand()[i].cardNumber)) {
										currentLow = puppet->getHand()[i];
								}
							}
							else{
								if (!lowerThanAce(currentLow.cardNumber,puppet->getHand()[i].cardNumber)) {
										currentLow = puppet->getHand()[i];
								}
							}
						}

						break;
					case BROKENHEARTS:
						if (puppet->getPlayerNumber() == heartBeat.currentTrickOwner) {
							//return any card but hearts here that is in the current hand
						}
						else if(hasSuit){
							//play the card with the lowest cardNumber in the current suit
							if(puppet->getHand()[i].suit == heartBeat.currentTrickSuit) {
								if (greaterThanAce(currentLow.cardNumber,puppet->getHand()[i].cardNumber)) {
									currentLow = puppet->getHand()[i];
								}
							}
						}
						else{
							//play the highest card in any suit
							if(puppet->getHand()[i].suit == heartBeat.currentTrickSuit) {
								if (!lowerThanAce(currentLow.cardNumber,puppet->getHand()[i].cardNumber)) {
									currentLow = puppet->getHand()[i];
								}
							}
						}
							break;
					default:
							break;
					}
				}
		}
	return currentLow;
}
//returns three cards to pass
Card* AI::choosePassCards(){
	Card passCards[3];
	passCards[0] = puppet->getHand()[0];
	passCards[1] = puppet->getHand()[1];
	passCards[2] = puppet->getHand()[2];
	return passCards;
}



Card AI::chooseTrickCardEasy(Rules &rules, theGauvin heartBeat){
	int count =0;
	Card returnCard;
	//Player person = *puppet;	//CHECK THIS. supposed to create a copy of the object puppet is pointing to.

	while(count <13){
		if(rules.checkIfValidCard( puppet->getHand()[count], heartBeat, *puppet)){
				returnCard = puppet->getHand()[count];
		}
		count++;

	}
	return returnCard;
}



