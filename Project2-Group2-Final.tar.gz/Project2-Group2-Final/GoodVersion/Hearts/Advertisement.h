/*
 * Advertisement.h
 *
 *      Author: John Fuller
 */

#ifndef ADVERTISEMENT_H_
#define ADVERTISEMENT_H_
#include "display.h"
#include <iostream>
#include <fstream>
#include <string>

class Advertisement{

public:
	Advertisement();
        string advert;
	ifstream file;
	string fileName;

	string getAdvert();
	void openFile(string userFile);
	void closeFile();
};


#endif /* ADVERTISEMENT_H_ */
