#ifndef STRUCTS_H_
#define STRUCTS_H_

//#pragma once

//cardNumber starts at 1 with ace and ends at 12 with the king
//card suit is  'c' for clubs, 'd' for diamonds, 'h' for hearts, and 's' for spades
typedef struct Card{
    int cardNumber;
    int penaltyValue;
    int suit;
	int xPosition;
	int yPosition;
	int player; //refers to which player owns the card (0 through 3)
	int deckNumber;
}Card;

typedef struct scoreBoard{
    int p1score;
    int p2score;
    int p3score;
    int p4score;
    int p1roundScore;
    int p2roundScore;
    int p3roundScore;
    int p4roundScore;
}scoreBoard;

//important stuff
typedef struct theGauvin{
	int currentPassState;
	int currentTurnState;
	int currentTrickOwner;
	int currentTrickSuit;
	int trickWinner;
	int twoOfClubsOwner;
	scoreBoard gameScoreBoard;
	int roundNumber;
	//int AIplaceHolder;
}theGauvin;

//enums
    enum pass{
        LEFT,
        RIGHT,
        ACROSS,
        NOPASS
    };
    enum turn{
        EMPTY=0,   //hand empty, end of round
        PASS,
        FIRSTHAND,
        UNBROKENHEARTS,
        BROKENHEARTS
    };
    enum suit{
        SPADES = 1,
        HEARTS,
        CLUBS,
        DIAMONDS
    };
    enum face{
        ACE = 1,
        JACK = 11,
        QUEEN = 12,
        KING = 13
    };


#endif // PLAYER_H_
