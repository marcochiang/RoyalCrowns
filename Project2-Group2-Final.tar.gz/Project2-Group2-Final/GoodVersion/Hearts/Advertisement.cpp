/*
 * Bank.cpp
 *
 *      Author: John Fuller
 */
#include "Advertisement.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "display.h"
#include <cstdlib>
#include <sstream>

using namespace std;

Advertisement::Advertisement(){
	advert = "";
}

void Advertisement::openFile(string userFile){
	fileName = userFile;
	file.open(fileName.c_str(), ifstream::in);
}

void Advertisement::closeFile(){
	file.close();
}

string Advertisement::getAdvert(){
	if(file.good()){
		getline(file, advert);
		return advert;
	}
	else{
		file.close();
		openFile(fileName);
		getline(file, advert);
		return advert;
	}
}


