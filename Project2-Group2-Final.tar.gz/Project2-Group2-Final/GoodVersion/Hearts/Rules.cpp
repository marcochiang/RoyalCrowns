/*
 * Rules.cpp
 *
 *  Created on: Oct 31, 2012
 *      Author: sireniti
 */

#include "Rules.h"
#include "Player.h"
#include "structs.h"

Rules::Rules() {
	// TODO Auto-generated constructor stub

}

Rules::~Rules() {
	// TODO Auto-generated destructor stub
}

//header shit


//cpp shit
#include "structs.h"
bool Rules::checkIfValidCard(Card &theCard, theGauvin &hb, Player &p0){
	if(theCard.suit !=-1){
		switch(hb.currentTurnState){
			case EMPTY:
				return false;
				break;

			case PASS:
				return false;
				break;

			case FIRSTHAND:
				if(p0.getPlayerNumber() == hb.twoOfClubsOwner){
					if(theCard.suit == CLUBS && theCard.cardNumber == 2) return true;
					else return false;
					//return false; //!!!
				}
				else{
					if(!p0.hasClubs() && !p0.hasSpades() && !p0.hasDiamonds()){
						hb.currentTurnState = BROKENHEARTS; //!!!!!!!
						return true;
					}
					else if(p0.hasClubs() && theCard.suit != CLUBS) return false;
					else if(theCard.suit == HEARTS || (theCard.suit == SPADES && theCard.cardNumber == QUEEN)) return false;
					else return true;
					//return false; //!!!
				}
				break;

			case UNBROKENHEARTS: {
				if(hb.currentTrickOwner == p0.getPlayerNumber()){
					if(!p0.hasClubs() && !p0.hasSpades() && !p0.hasDiamonds()){
						hb.currentTurnState = BROKENHEARTS; //!!!!!!!
					return true;
					}
					else if(theCard.suit != HEARTS){
						return true;
					}

					else return false;
					//return false; //!!!
				}
				else{
					if(p0.hasSuit(hb.currentTrickSuit) && theCard.suit != hb.currentTrickSuit) return false;
					else return true;
					//return false; //!!!
				}
			}
			break;

			case BROKENHEARTS: {
				if(hb.currentTrickOwner == p0.getPlayerNumber()){
					return true;
				}
				else{
					if(p0.hasSuit(hb.currentTrickSuit) && theCard.suit != hb.currentTrickSuit) return false;
					else return true;
					//return false; //!!!
				}
			}
				break;

			default:
				return false;
				break;
		}
	}
	else return false;
	return false;
}

