#ifndef PLAYER_H
#define PLAYER_H
#include <string>
#include "structs.h"
//#include "Rules.h"

//#pragma once

using std::string;

class Player
{
    public:
    //functions
        Player();
        virtual ~Player();

        void setCardsPassed(int i, Card c);
        void setPlayerNumber(int x);
        int getPlayerNumber();
        bool isInTrickPile(int suit, int cardNumber); //need to write in .cpp
        Card findInTrickPile(int suit, int cardNumber); //need to write in .cpp
        string getName();
        void setName(string name); //sets the name of the player
        Card playCard(Card card);  //returns a card from the player's hand (deletes that card from the hand)
        Card playCard(int cardNumber, int suit); // same as above
        Card* getHand(); //returns an array of the cards in the hand
        Card getCardPlayed(); //returns the last card played
        Card* getTrickPile(); //returns the array of cards won so far
        void populateHand(int index, Card card); //adds card to hand
        void winTrickPile(Card* trick); //takes cards from table and places them in the trick pile array
        Card* getCardsPassed(); //returns an array of the 3 cards passed
        void setScore(int points); //sets the player's score to specified points value
        void getScore();    //returns the current score of the player
		int getNumberOfTrickPileCards(); //returns the value of the private var numberOfTrickPileCards
		void setNullTrickPileCard(int i);
		void setNullPassCard(int i);
		void setNullHandCard(int i);
		void setPassArray(Card *array);
		void incrementAIPlaceHolder();
		void setAIplaceHolder(int newPlaceHolder);
		int getAIplaceHolder();
		void setNumberOfTrickPileCards(int numOfCards);
		bool hasHearts();	//TODO: write in .cpp
		bool hasSpades();
		bool hasDiamonds();
		bool hasClubs();
		bool hasSuit(int suit);
		void setHand(int i, Card c);
    protected:

    private:

    //variables
		int AIplaceHolder;
        string playerName;      //the name of the player
        Card playerHand[13];    //cards in player's hand
        Card trickPile[52]; //all cards won from tricks in current round
        Card cardPlayed;     //card played during current turn
        int numberOfTrickPileCards; //the size of the trick pile array
        int score;         //the player's score
        Card cardsPassed[3]; //contains cards passed
        int playerNum;

    //functions
        Card* choosePassCards(Card card1, Card card2, Card card3); //fills in cards passed array and returns array
};

#endif // PLAYERSTUB_H
