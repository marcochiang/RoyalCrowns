/*
 * CardCounter.h
 *
 *  Created on: Nov 21, 2012
 *      Author: Marco Chiang
 */

#ifndef CARDCOUNTER_H_
#define CARDCOUNTER_H_

class CardCounter{

public:
	struct CardCount;
	CardCounter();
	int totalCardCount;
	int goFishCardCount;
	int heartsCardCount;
	int blackJackCardCount;
	void incrCardCount();
};


#endif /* CARDCOUNTER_H_ */
