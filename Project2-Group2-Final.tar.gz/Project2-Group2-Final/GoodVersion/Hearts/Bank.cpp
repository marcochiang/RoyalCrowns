/*
 * Bank.cpp
 *
 *      Author: John Fuller
 */
#include "Bank.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "display.h"
#include <cstdlib>
#include <sstream>
#include <math.h>

using namespace std;

Bank::Bank(){
	bank = 2000;
	bet = 0;
}

//subtracts bet from bank
void Bank::lossBet(){
	bank -= bet;
}

//adds bet to the bank
void Bank::winBet(){
	bank += bet;
}
//returns bet provided via user input. Keeps asking until valid and bet is less than bank
void Bank::getBet(){
	string userBet = "";
	cin >> userBet;
	while(1){
		sscanf(userBet.c_str(), "%d", &bet);
		if(bet < 0 || !sscanf(userBet.c_str(), "%d", &bet)){
		gameDisplay.bannerTop("Please enter a whole positive number");
		gameDisplay.updateScreen();	
		}
		else{
			if(bet > bank){
				gameDisplay.bannerTop("Please enter an amount less than or equal to your current bank.");
				gameDisplay.updateScreen();
			}
			else{
				stringstream messageString;
				messageString.str("");
				messageString << "You have bet $" << userBet;
				gameDisplay.bannerTop(messageString.str());
				gameDisplay.updateScreen();
				sleep(2);
				break;
			}
		}	
		cin >> userBet;	
	}

}
