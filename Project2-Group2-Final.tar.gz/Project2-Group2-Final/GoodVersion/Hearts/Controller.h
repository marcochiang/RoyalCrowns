#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "Player.h"
#include "structs.h"
#include "display.h"
#include <string>
#include "AI.h"

//#pragma once

using namespace std;

class Controller
{
    public:
    //variables
        Card deck[52]; //holds the 52 cards

    //functions
        //reset the player's properties, redeal, reinitialize some heart beat properties
        void restartRound(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb);
        void displayLastFourTrickPileCards(display &gameDisplay, Player &player);
        bool isEmpty(Player p1, Player p2, Player p3, Player p4);
        void eraseFirstFourHandCards(display &gameDisplay);
        //checks card and waits until valid one plays
        void AIplayTrickCard(AI brain, Rules rules, display &gameDisplay, Player &player, theGauvin &hb);
        void initiatePasses(Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, Rules &rulebook, display &gameDisplay, theGauvin &heartBeat);
        //returns the number of the trick winner
        int determineTrickWinner(theGauvin &heartBeat);
        void shootForTheSun(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb, display &gd);
        void shootForTheMoon(theGauvin &hb, display &gd);
        void wait(display gameDisplay);
        //moves the cards into the respective arrays based on Pass State and displays the users newly received cards
        void pass(display &gameDisplay, theGauvin &heartBeat, Player &p1, Player &p2, Player &p3, Player &p4);
        void messageUserBox(int x, int y, string message, display &gameDisplay);
        void displayScoreBoard(display &gd, theGauvin &hb);
		//get three pass cards chosen by the user and move them to the pass card array
		void userPickPassCards(display &gameDisplay, Player &player);
		//moves the users trick card to the users spot on the table and
		//adds it to the trickCardsOnTable array
		void cardUserTrick(display &gameDisplay, Card card, int playerNum);
		void moveAIPassCards(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb);
		Card* getTrickCardsOnTable();
		//returns true if card in user's hand was clicked on; also moves it to the user's trick spot
		void userPlayTrickCard(display &gameDisplay, Player &player, Rules rules, theGauvin &hb);
		void userCardDisplay(display &gameDisplay, int position, Card &card); //displays card at specified "position"; 1= bottom left , 13 = bottom right
		void displayHand(display &gameDisplay, Player &player); //calls userCardDisplay to display the whole hand
        Controller();
        virtual ~Controller();
        Card* getTrickCards();  //return the array cards currently played on the table for a trick

        Player getTrickOwner();
        Player getTrickWinner();

        bool isGameOver();  //checks if any players have a score of 100 or more
        bool isHandOver(); //checks if all players hands are empty and the turnState is empty
        void initializeDeck(); // creates 52 cards in the deck array
        //takes in the location the user clicks on and if it matches a card location then returns true and if it doesn't returns false
		bool moveUserCard(display &gameDisplay, Player &player, int clickX, int clickY, Rules rules, theGauvin &hb);
		void deal(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb); //deals 13 cards to each of the four players and changes turn state to pass
		void resetTrickOwner(theGauvin &hb);
		int detectTurnState(Player p1, Player p2, Player p3, Player p4, theGauvin hb);
		void playCardsCW(theGauvin &hb, Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, display &gd, Rules zeRules);
		//clears cards from display
		void clearTrickCardsDisplay(display &gameDisplay);
		//erase first players card
		void erasePlayerOneCard(display &gameDisplay);
		//erase second players card
		void erasePlayerTwoCard(display &gameDisplay);
		//erase third players card
		void erasePlayerThreeCard(display &gameDisplay);
		//erases users trick card when displayed
		void eraseUserTrick(display &gameDisplay);
		void putTrickCardsInWinnersPile(int winner, Player &p1, Player &p2, Player &p3, Player &p4);
		bool moveAICard(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb);
		void tallyPoints(theGauvin &hb);
		void clearTrickCardArray();
		void sortHandInsertion(Player &player);
		void displayTrickCardArray(display &gd);
		void findTwoOfClubs(Player p1, Player p2, Player p3, Player p4, theGauvin &hb);
		void sortHandBubble(Player &player);
		bool greaterThanAce(int firstCardNumber, int secondCardNumber);
		bool lowerThanAce(int firstCardNumber, int secondCardNumber);
		void displayMessageBox(display &gameDisplay, theGauvin &hb);
		void bannerPlayerScoreRoundNumber(display &gameDisplay, theGauvin &hb);
		void changePassState(theGauvin &hb, int pass); //manually change pass state
		void changeTurnState(theGauvin &hb, int turn); //manually change turn state
		void advancePassState(theGauvin &hb); //automatically change pass state and return the pass state it is changed to
		//int detectTurnState(); //returns overall turn state depending on player's hands, won trick cards, etc.
		void displayPassCards(display &gameDisplay, Player &player);
		void moveAIPassCardsDumb(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb);
		bool moveAICardDumb(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb);
		void playCardsCWDumb(theGauvin &hb, Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, display &gd, Rules zeRules);
		int aceNumber(int n);
		void makeNullCard(Card &card);

   protected:

    private:
    //variables
		
        Card trickCardsOnTable[5]; //cards curently on table
        // scoreBoard scores;  //struct of all players scores for the entire game
        //int passState;
        //int turnState;
/*
Should trickOwner and trickWinner be strings containing the name of the players or are
they clones of the players?
*/


    //functions
		//takes a card in and nulls it's suit, cardnumber, and x, y positions
		
        void addToScore(Player thePlayer, int points); //adds specified points to specified player's score
        bool findInTrickPile(Player thePlayer, int theSuit);   //finds the presense of any card of the specified suit in the specified player's trick pile
        bool findInTrickPile(Player thePlayer, Card theCard);   //finds the presense of the specified card in the specified player's trick pile
        bool findInTrickPile(Player thePlayer, int theSuit, int theCardNumber);    //finds the presense of the specified card in the specified player's trick pile
//        void changePassState(int pass); //manually change pass state
//        void changeTurnState(int turn); //manually change turn state
//        int advancePassState(); //automatically change pass state and return the pass state it is changed to
//        int detectTurnState(); //returns overall turn state depending on player's hands, won trick cards, etc.
       
        void shuffle(); //randomly rearranges the deck
        bool handEmpty(Player thePlayer);   //returns true if the specified player's hand is empty
        //Player whoWonTrick(); //returns who won the current trick
        //void initializePlayers();   //initializes four players as class variables
        //void initializeNames();     //grabs player names upon starting a new game, assigns names to any computer players
	


};


#endif // CONTROLLER_H

