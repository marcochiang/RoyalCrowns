#include "Controller.h"
#include <time.h>
#include "Player.h"
#include "structs.h"
#include <sstream>
#include "AI.h"
#include <stdlib.h>
#include <time.h>
#include "Rules.h"
#include <ncursesw/ncurses.h>
#include "Advertisement.h"

using namespace std;

extern Advertisement ads;

Controller::Controller()
{
	//passState=NOPASS;
	//turnState=EMPTY;
    //ctor
}

Controller::~Controller()
{
    //dtor
}




//displays cards in the users hand, takes in the an int which describes the location of the card
void Controller::userCardDisplay(display &gameDisplay, int position, Card &card){
			gameDisplay.displayCard(((position*6)+1),18,card.suit,(card.cardNumber),A_NORMAL);
			card.xPosition=((position*6)+1); //sets the current x position to the card struct xPosition
			card.yPosition=(18); //sets the current y position to the card struct yPosition
}

void Controller::resetTrickOwner(theGauvin &hb){
	hb.trickWinner = hb.currentTrickOwner;
}

void Controller::AIplayTrickCard(AI brain, Rules rules, display &gameDisplay, Player &player, theGauvin &hb){
	int counter = 0;
	while(counter<1){

		if(moveAICardDumb(player, gameDisplay, brain, rules, hb)){
			counter++;
		}
	}

}
//run this function is a while loop to wait for a user to pick the correct card
void Controller::userPlayTrickCard(display &gameDisplay, Player &player, Rules rules, theGauvin &hb){
	// using a stringstream rather than a string to make making the banner easier
	stringstream messageString;
	messageString.str("");
	messageString << "Pick a card to play for the trick";
	gameDisplay.bannerTop(messageString.str());
	int key = gameDisplay.captureInput();
	int counter = 0;
	while(counter < 1){
		key = gameDisplay.captureInput();
		if(key != 0 && key == -1){
			if(moveUserCard(gameDisplay, player, gameDisplay.getMouseEventX(), gameDisplay.getMouseEventY(), rules, hb)){
				gameDisplay.updateScreen();
				counter++;
			}
		}
	}
	/*
	do {
		if(moveCard(gameDisplay, player, gameDisplay.getMouseEventX(), gameDisplay.getMouseEventY())){
			gameDisplay.updateScreen();
			return true;
		}
		key = gameDisplay.captureInput();
	}
	while(key != 0 && key == -1);
	return false;
	*/
}
void Controller::restartRound(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb ){
		int numberOfDeckCards = 0;
		Player *currentPlayer;
		for(int k = 1; k<5; k++){
			int x = 0;
			switch (k){
			case 1:
				x = p1.getNumberOfTrickPileCards();
				currentPlayer = &p1;
				break;
			case 2:
				x = p2.getNumberOfTrickPileCards();
				currentPlayer = &p2;
				break;
			case 3:
				x = p3.getNumberOfTrickPileCards();
				currentPlayer = &p3;
				break;
			case 4:
				x = p4.getNumberOfTrickPileCards();
				currentPlayer = &p4;
				break;
			}
			for(int i = 0; i<x; i++){
				deck[numberOfDeckCards]= currentPlayer->getTrickPile()[i];
				currentPlayer->setNullTrickPileCard(i);
				currentPlayer->setAIplaceHolder(0);
			}
		}
		p1.setNumberOfTrickPileCards(0);
		p2.setNumberOfTrickPileCards(0);
		p3.setNumberOfTrickPileCards(0);
		p4.setNumberOfTrickPileCards(0);

		hb.gameScoreBoard.p1roundScore = 0;
		hb.gameScoreBoard.p2roundScore = 0;
		hb.gameScoreBoard.p3roundScore = 0;
		hb.gameScoreBoard.p4roundScore = 0;

		hb.currentTurnState = EMPTY;
		hb.roundNumber++;
		initializeDeck();	//might not need this
		//deal(p1,p2,p3,p4,hb);
}

void Controller::shootForTheSun(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb, display &gd){
	int shooter = 0;

	if (p1.getNumberOfTrickPileCards()==52){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score - 26;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 52;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 52;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 52;
		shooter = 1;
	}
	if (p2.getNumberOfTrickPileCards()==52){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 52;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score - 26;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 52;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 52;
		shooter = 2;
	}
	if (p3.getNumberOfTrickPileCards()==52){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 52;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 52;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score - 26;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 52;
		shooter = 3;
	}
	if (p4.getNumberOfTrickPileCards()==52){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 52;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 52;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 52;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score - 26;
		shooter = 4;
	}

	if(shooter != 0){
		stringstream messageString;
		messageString.str("");
		messageString << "Player " << shooter << " shot the sun!!! Everyone else gets 52 points.";
		gd.bannerTop(messageString.str());
		wait(gd);
	}
}

void Controller::shootForTheMoon(theGauvin &hb, display &gd){
	int shooter = 0;

	if (hb.gameScoreBoard.p1roundScore==26){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score - 26;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 26;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 26;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 26;
		shooter = 1;
	}
	if (hb.gameScoreBoard.p1roundScore==26){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 26;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score - 26;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 26;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 26;
		shooter = 2;
	}
	if (hb.gameScoreBoard.p1roundScore==26){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 26;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 26;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score - 26;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + 26;
		shooter = 3;
	}
	if (hb.gameScoreBoard.p1roundScore==26){
		hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + 26;
		hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + 26;
		hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + 26;
		hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score - 26;
		shooter = 4;
	}

	if(shooter != 0){
		stringstream messageString;
		messageString.str("");
		messageString << "Player " << shooter << " shot the moon!!! Everyone else gets 26 points.";
		gd.bannerTop(messageString.str());
		wait(gd);
	}
}

//has each player play a card from the hand onto the table in the correct order based on who is supposed to go first
void Controller::playCardsCW(theGauvin &hb, Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, display &gd, Rules zeRules){
	//hb.roundNumber = hb.roundNumber+1;

	int firstPlayer = hb.currentTrickOwner;

	switch(firstPlayer){
		case 1:
			userPlayTrickCard(gd, p1, zeRules, hb);
			if(moveAICard(p2, gd, ai2, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p3, gd, ai3, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p4, gd, ai4, zeRules, hb)) gd.updateScreen();
			break;

		case 2:
			if(moveAICard(p2, gd, ai2, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p3, gd, ai3, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p4, gd, ai4, zeRules, hb)) gd.updateScreen();
			userPlayTrickCard(gd, p1, zeRules, hb);
			break;


		case 3:
			if(moveAICard(p3, gd, ai3, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p4, gd, ai4, zeRules, hb)) gd.updateScreen();
			userPlayTrickCard(gd, p1, zeRules, hb);
			if(moveAICard(p2, gd, ai2, zeRules, hb)) gd.updateScreen();
			break;

		case 4:
			if(moveAICard(p4, gd, ai4, zeRules, hb)) gd.updateScreen();
			userPlayTrickCard(gd, p1, zeRules, hb);
			if(moveAICard(p2, gd, ai2, zeRules, hb)) gd.updateScreen();
			if(moveAICard(p3, gd, ai3, zeRules, hb)) gd.updateScreen();
			break;
	}
}

void Controller::playCardsCWDumb(theGauvin &hb, Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, display &gd, Rules zeRules){
	//hb.roundNumber = hb.roundNumber+1;

	int firstPlayer = hb.currentTrickOwner;

	switch(firstPlayer){
		case 1:
			p2.setAIplaceHolder(0);
			p3.setAIplaceHolder(0);
			p4.setAIplaceHolder(0);

			userPlayTrickCard(gd, p1, zeRules, hb);
			hb.currentTrickSuit = trickCardsOnTable[1].suit;

			AIplayTrickCard(ai2, zeRules,gd, p2, hb);
			gd.updateScreen();

			AIplayTrickCard(ai3, zeRules,gd, p3, hb);
			gd.updateScreen();

			AIplayTrickCard(ai4, zeRules,gd, p4, hb);
			gd.updateScreen();
			//hb.AIplaceHolder++;
			break;

		case 2:
			p2.setAIplaceHolder(0);
			p3.setAIplaceHolder(0);
			p4.setAIplaceHolder(0);

			AIplayTrickCard(ai2, zeRules,gd, p2, hb);
			gd.updateScreen();
			hb.currentTrickSuit = trickCardsOnTable[2].suit;

			AIplayTrickCard(ai3, zeRules,gd, p3, hb);
			gd.updateScreen();

			AIplayTrickCard(ai4, zeRules,gd, p4, hb);
			gd.updateScreen();

			userPlayTrickCard(gd, p1, zeRules, hb);

			//hb.AIplaceHolder++;
			break;


		case 3:
			p2.setAIplaceHolder(0);
			p3.setAIplaceHolder(0);
			p4.setAIplaceHolder(0);

			AIplayTrickCard(ai3, zeRules,gd, p3, hb);
			gd.updateScreen();
			hb.currentTrickSuit = trickCardsOnTable[3].suit;

			AIplayTrickCard(ai4, zeRules,gd, p4, hb);
			gd.updateScreen();

			userPlayTrickCard(gd, p1, zeRules, hb);

			AIplayTrickCard(ai2, zeRules,gd, p2, hb);
			gd.updateScreen();


			//hb.AIplaceHolder++;
			break;

		case 4:
			p2.setAIplaceHolder(0);
			p3.setAIplaceHolder(0);
			p4.setAIplaceHolder(0);


			AIplayTrickCard(ai4, zeRules,gd, p4, hb);
			gd.updateScreen();
			hb.currentTrickSuit = trickCardsOnTable[4].suit;

			userPlayTrickCard(gd, p1, zeRules, hb);

			AIplayTrickCard(ai2, zeRules,gd, p2, hb);
			gd.updateScreen();

			AIplayTrickCard(ai3, zeRules,gd, p3, hb);
			gd.updateScreen();

			//hb.AIplaceHolder++;
			break;
	}
}


void Controller::tallyPoints(theGauvin &hb){
	for(int i = 1; i<5; i++){
		switch(hb.trickWinner){

			case 1:
				hb.gameScoreBoard.p1score = hb.gameScoreBoard.p1score + trickCardsOnTable[i].penaltyValue;
				hb.gameScoreBoard.p1roundScore = hb.gameScoreBoard.p1roundScore + trickCardsOnTable[i].penaltyValue;
				break;
			case 2:
				hb.gameScoreBoard.p2score = hb.gameScoreBoard.p2score + trickCardsOnTable[i].penaltyValue;
				hb.gameScoreBoard.p2roundScore = hb.gameScoreBoard.p2roundScore + trickCardsOnTable[i].penaltyValue;
				break;
			case 3:
				hb.gameScoreBoard.p3score = hb.gameScoreBoard.p3score + trickCardsOnTable[i].penaltyValue;
				hb.gameScoreBoard.p3roundScore = hb.gameScoreBoard.p3roundScore + trickCardsOnTable[i].penaltyValue;
				break;
			case 4:
				hb.gameScoreBoard.p4score = hb.gameScoreBoard.p4score + trickCardsOnTable[i].penaltyValue;
				hb.gameScoreBoard.p4roundScore = hb.gameScoreBoard.p4roundScore + trickCardsOnTable[i].penaltyValue;
				break;
		}
	}
}

void Controller::messageUserBox(int x, int y, string message, display &gameDisplay){
   if(x>1&&y>1){
       //gameDisplay.drawBox(x-1,y-1,(message.sizeof()+1),3,A_BOLD);
       //mvprintw(x,y,message);
       gameDisplay.updateScreen();
   }
}

void Controller::sortHandInsertion(Player &player){
	Card key;
	int j;
	for(int i=1;i<13;i++)
	{
		key=player.getHand()[i];
		j=i-1;

		while((player.getHand()[i-1].deckNumber > key.deckNumber) && (j >= 0))
		{
			//player.getHand()[j+1] = player.getHand()[j];
			player.setHand(j+1,player.getHand()[j]);
			j=j-1;
		}
		player.setHand(j+1,key);
	}
}

void Controller::wait(display gameDisplay){
int key;
	int counter = 0;
	while(counter <1){
		key = gameDisplay.captureInput();
		if(key != 0 && key == -1){
			counter++;
		}
	}
}

void Controller::initiatePasses(Player &p1, Player &p2, Player &p3, Player &p4, AI &ai2, AI &ai3, AI &ai4, Rules &rulebook, display &gameDisplay, theGauvin &heartBeat){
	stringstream messageString;
	switch(heartBeat.currentPassState){
		case LEFT:
			messageString.str("");
			messageString << "The pass state is LEFT. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			userPickPassCards(gameDisplay, p1);
			moveAIPassCardsDumb(p2, gameDisplay, ai2, rulebook, heartBeat);
			moveAIPassCardsDumb(p3, gameDisplay, ai3, rulebook, heartBeat);
			moveAIPassCardsDumb(p4, gameDisplay, ai4, rulebook, heartBeat);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

//			displayHand(gameDisplay,p1);
//			gameDisplay.updateScreen();

			pass(gameDisplay, heartBeat, p1, p2, p3, p4);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

			displayHand(gameDisplay,p1);
			gameDisplay.updateScreen();

			messageString.str("");
			messageString << "Got Player 4's pass cards. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			changePassState(heartBeat, RIGHT);
			break;

		case RIGHT:
			messageString.str("");
			messageString << "The pass state is RIGHT. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			userPickPassCards(gameDisplay, p1);
			moveAIPassCardsDumb(p2, gameDisplay, ai2, rulebook, heartBeat);
			moveAIPassCardsDumb(p3, gameDisplay, ai3, rulebook, heartBeat);
			moveAIPassCardsDumb(p4, gameDisplay, ai4, rulebook, heartBeat);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

//			displayHand(gameDisplay,p1);
//			gameDisplay.updateScreen();

			pass(gameDisplay, heartBeat, p1, p2, p3, p4);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

			displayHand(gameDisplay,p1);
			gameDisplay.updateScreen();

			messageString.str("");
			messageString << "Got Player 2's pass cards. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			changePassState(heartBeat, ACROSS);
			break;

		case ACROSS:
			messageString.str("");
			messageString << "The pass state is ACROSS. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			userPickPassCards(gameDisplay, p1);
			moveAIPassCardsDumb(p2, gameDisplay, ai2, rulebook, heartBeat);
			moveAIPassCardsDumb(p3, gameDisplay, ai3, rulebook, heartBeat);
			moveAIPassCardsDumb(p4, gameDisplay, ai4, rulebook, heartBeat);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

//			displayHand(gameDisplay,p1);
//			gameDisplay.updateScreen();

			pass(gameDisplay, heartBeat, p1, p2, p3, p4);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

			displayHand(gameDisplay,p1);
			gameDisplay.updateScreen();

			messageString.str("");
			messageString << "Got Player 3's pass cards. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			changePassState(heartBeat, NOPASS);
			break;

		case NOPASS:
			messageString.str("");
			messageString << "The pass state is NOPASS. Click to continue.";
			gameDisplay.bannerTop(messageString.str());
			wait(gameDisplay);

			sortHandBubble(p1);
			sortHandBubble(p2);
			sortHandBubble(p3);
			sortHandBubble(p4);

			displayHand(gameDisplay,p1);
			gameDisplay.updateScreen();

			changePassState(heartBeat, LEFT);
			break;
	}
}

bool Controller::lowerThanAce(int firstCardNumber, int secondCardNumber){
	if(firstCardNumber == 1) firstCardNumber = 14;
	if(secondCardNumber == 1) secondCardNumber = 14;

	if(firstCardNumber < secondCardNumber)return true;
	else return false;
}

bool Controller::greaterThanAce(int firstCardNumber, int secondCardNumber){
	if(firstCardNumber == 1) firstCardNumber = 14;
	if(secondCardNumber == 1) secondCardNumber = 14;

	if(firstCardNumber > secondCardNumber)return true;
	else return false;
	return true;
}

void Controller::sortHandBubble(Player &player)
{
	//lol bubblesort.
	Card temp;
	for(int i=0;i<13-1;i++)
		for(int j=0;j<13-1-i;j++)
			if(player.getHand()[j].deckNumber> player.getHand()[j+1].deckNumber)
			{
				temp=player.getHand()[j];
				//a[j]=a[j+1];
				player.setHand(j,player.getHand()[j+1]);
				//a[j+1]=temp;
				player.setHand(j+1,temp);
			}

}

void Controller::displayScoreBoard(display &gd, theGauvin &hb){
	stringstream p1, p2, p3, p4;

	int i = hb.gameScoreBoard.p1score;
	int ii = hb.gameScoreBoard.p2score;
	int iii = hb.gameScoreBoard.p3score;
	int iiii = hb.gameScoreBoard.p4score;

	p1 << "Player 1: " << i;
	p2 << "Player 2: " << ii;
	p3 << "Player 3: " << iii;
	p4 << "Player 4: " << iiii;

	string play1 = p1.str();
	string play2 = p2.str();
	string play3 = p3.str();
	string play4 = p4.str();

	gd.drawBox(1,1,18,6,A_NORMAL);
	mvprintw(1,2,"Scores:");
	mvprintw(2,3,(char*)play1.c_str());
	mvprintw(3,3,(char*)play2.c_str());
	mvprintw(4,3,(char*)play3.c_str());
	mvprintw(5,3,(char*)play4.c_str());

	gd.updateScreen();
}

void Controller::displayMessageBox(display &gameDisplay, theGauvin &hb){
	stringstream messageString;

	int Game = hb.roundNumber;

	string state = "";

	switch(hb.currentTurnState){
		case EMPTY:
			state = "New round";
			break;
		case PASS:
			state = "Passing cards";
			break;
		case FIRSTHAND:
			state = "First trick";
			break;
		case UNBROKENHEARTS:
			state = "Hearts unbroken";
			break;
		case BROKENHEARTS:
			state = "Hearts broken";
			break;
	}

	messageString.str("");
	messageString << ads.getAdvert() << " " << state << " Round: " << Game;
	gameDisplay.bannerBottom(messageString.str());
	gameDisplay.updateScreen();
}

void Controller::bannerPlayerScoreRoundNumber(display &gameDisplay, theGauvin &hb){
	tallyPoints(hb);
	stringstream messageString;
	messageString.str("");
	messageString << "Player 1: " << hb.gameScoreBoard.p1score << ", Player 2: "<< hb.gameScoreBoard.p2score << ", Player 3: " << hb.gameScoreBoard.p3score << ", Player 4: " << hb.gameScoreBoard.p4score << "Round: " << hb.roundNumber;
	gameDisplay.bannerBottom(messageString.str());
}

void Controller::findTwoOfClubs(Player p1, Player p2, Player p3, Player p4, theGauvin &hb)
{
	if(p1.getHand()[0].deckNumber == 0) hb.twoOfClubsOwner=1;
	if(p2.getHand()[0].deckNumber == 0) hb.twoOfClubsOwner=2;
	if(p3.getHand()[0].deckNumber == 0) hb.twoOfClubsOwner=3;
	if(p4.getHand()[0].deckNumber == 0) hb.twoOfClubsOwner=4;
}

void Controller::clearTrickCardArray(){
	for(int i = 1; i<5; i++){
		makeNullCard(trickCardsOnTable[i]);
	}
}

void Controller::putTrickCardsInWinnersPile(int winner, Player &p1, Player &p2, Player &p3, Player &p4){
	switch(winner){
	case 1:
		p1.winTrickPile(trickCardsOnTable);
		break;

	case 2:
		p2.winTrickPile(trickCardsOnTable);
		break;

	case 3:
		p3.winTrickPile(trickCardsOnTable);
		break;

	case 4:
		p4.winTrickPile(trickCardsOnTable);
		break;
	}
}

void Controller::displayTrickCardArray(display &gd){
	for(int i = 1; i<5; i++){
		cardUserTrick(gd, trickCardsOnTable[i], i);
		gd.updateScreen();
	}
}

//Clear cards display
void Controller::clearTrickCardsDisplay(display &gameDisplay){

    erasePlayerOneCard(gameDisplay);
    erasePlayerThreeCard(gameDisplay);
    erasePlayerTwoCard(gameDisplay);
    eraseUserTrick(gameDisplay);
}

//erase first players card
void Controller::erasePlayerOneCard(display &gameDisplay){
    gameDisplay.eraseBox(37,1,6,5);
    gameDisplay.updateScreen();
}

//erase second players card
void Controller::erasePlayerTwoCard(display &gameDisplay){
    gameDisplay.eraseBox(1,7,6,5);
    gameDisplay.updateScreen();
}

//erase third players card
void Controller::erasePlayerThreeCard(display &gameDisplay){
    gameDisplay.eraseBox(73,7,6,5);
    gameDisplay.updateScreen();
}

//erases users trick card when displayed
void Controller::eraseUserTrick(display &gameDisplay){
    gameDisplay.eraseBox(37,13,6,5);
    gameDisplay.updateScreen();
}



int Controller::determineTrickWinner(theGauvin &heartBeat){
	int winner = 0;
	int cardNumberHigh = -1;
	int currentCardNumber = -1;
	for(int i = 1; i<5; i++){
		if(trickCardsOnTable[heartBeat.currentTrickOwner].suit == trickCardsOnTable[i].suit){
			currentCardNumber = trickCardsOnTable[i].deckNumber%13;
			if((cardNumberHigh) < currentCardNumber){
				cardNumberHigh = currentCardNumber;
				winner = i;
			}
		}
	}


	return winner;
}

int Controller::aceNumber(int n){
	if(n == ACE) n = 14;
	return n;

}

//Pass and display the cards that get passed to the user player
void Controller::pass(display &gameDisplay, theGauvin &heartBeat, Player &p1, Player &p2, Player &p3, Player &p4){

	switch(heartBeat.currentPassState){
		case LEFT:

			//displays the cards from the left being passed to the user in the correct location
//			for(int i = 0; i<3; i++){
//				int xCoord = (((i)*6)+1);
//				gameDisplay.displayCard(xCoord, 18, p4.getCardsPassed()[i].suit, p4.getCardsPassed()[i].cardNumber, A_NORMAL);
//				gameDisplay.updateScreen();
//			}

			//move each player's cards to the other player's hand with the right locations and reassigning the playerNumber on the card
			for(int i = 0; i<3; i++){
				int cardIndex = i;

				p1.setHand(cardIndex, p4.getCardsPassed()[i]);
				p4.setNullPassCard(i);

				p2.setHand(cardIndex, p1.getCardsPassed()[i]);
				p1.setNullPassCard(i);

				p3.setHand(cardIndex, p2.getCardsPassed()[i]);
				p2.setNullPassCard(i);

				p4.setHand(cardIndex, p3.getCardsPassed()[i]);
				p3.setNullPassCard(i);
			}


			break;

		case RIGHT:

			//displays the cards from the right being passed to the user in the correct location
			for(int i = 0; i<3; i++){
				int xCoord = (((i)*6)+1);
				gameDisplay.displayCard(xCoord, 18, p2.getCardsPassed()[i].suit, p2.getCardsPassed()[i].cardNumber, A_NORMAL);
			}

			for(int i = 0; i<3; i++){
				int cardIndex = i;

				p1.setHand(cardIndex, p2.getCardsPassed()[i]);
				p2.setNullPassCard(i);

				p2.setHand(cardIndex, p3.getCardsPassed()[i]);
				p3.setNullPassCard(i);

				p3.setHand(cardIndex, p4.getCardsPassed()[i]);
				p4.setNullPassCard(i);

				p4.setHand(cardIndex, p1.getCardsPassed()[i]);
				p1.setNullPassCard(i);
			}

			//move each player's cards to the other player's hand
			break;

		case ACROSS:
			//displays the cards from across being passed to the user in the correct location
			for(int i = 0; i<3; i++){
				int xCoord = (((i)*6)+1);
				gameDisplay.displayCard(xCoord, 18, p3.getCardsPassed()[i].suit, p3.getCardsPassed()[i].cardNumber, A_NORMAL);
			}

			for(int i = 0; i<3; i++){
				int cardIndex = i;

				p1.setHand(cardIndex, p3.getCardsPassed()[i]);
				p3.setNullPassCard(i);

				p2.setHand(cardIndex, p4.getCardsPassed()[i]);
				p4.setNullPassCard(i);

				p3.setHand(cardIndex, p1.getCardsPassed()[i]);
				p1.setNullPassCard(i);

				p4.setHand(cardIndex, p2.getCardsPassed()[i]);
				p2.setNullPassCard(i);
			}

			//move each player's cards to the other player's hand
			break;
		case NOPASS:

			break;
	}
}


void Controller::makeNullCard(Card &card){
	card.suit = -1;
	card.cardNumber = -1;
	card.xPosition = -1; 
	card.yPosition = -1; 
	card.player = -1;
	card.deckNumber = -1;
	card.penaltyValue = 0;
}

//allows user to pick three pass cards and moves them to the pass cards array
void Controller::userPickPassCards(display &gameDisplay, Player &player){
	// using a stringstream rather than a string to make making the banner easier
	stringstream messageString;
	messageString.str("");
	messageString << "Pick three pass cards";
	gameDisplay.bannerTop(messageString.str());
	int key; 
	int counter = 0;
	while(counter < 3){
		key = gameDisplay.captureInput();
		if(key != 0 && key == -1){
				for(int i = 0; i<13; i++){//change this when we figure out how we are going to delete the cards
					if(player.getHand()[i].yPosition >= 0 || player.getHand()[i].xPosition >= 0){
					//check if the click matches one in the players hand on the screen
						if( (gameDisplay.getMouseEventX() >= (player.getHand())[i].xPosition && gameDisplay.getMouseEventX()<((player.getHand())[i].xPosition+6)) 
							&& (gameDisplay.getMouseEventY() >= (player.getHand())[i].yPosition && gameDisplay.getMouseEventY()<((player.getHand())[i].yPosition+5) )){
							//erase the card and move it to the pass array
							gameDisplay.eraseBox(player.getHand()[i].xPosition, player.getHand()[i].yPosition, 6, 5);
							player.setCardsPassed(counter, player.getHand()[i]);
							//also delete from the player's hand and put in pass array

							//player.getCardsPassed()[counter] = player.getHand()[i];
							player.setNullHandCard(i);
							counter++;
						}
					}
				}
		}
	
	}
	
	
}

//displays users card
void Controller::cardUserTrick(display &gameDisplay, Card card, int playernumber){
	switch(playernumber){
	case 1:
		gameDisplay.displayCard(37,13,(card.suit),(card.cardNumber),A_NORMAL);
    	gameDisplay.updateScreen();
    	break;
	case 2:
		gameDisplay.displayCard(1,7,(card.suit),(card.cardNumber),A_NORMAL);
    	gameDisplay.updateScreen();
    	break;
	case 3:
		gameDisplay.displayCard(37,1,(card.suit),(card.cardNumber),A_NORMAL);
    	gameDisplay.updateScreen();
    	break;
	case 4:
		gameDisplay.displayCard(73,7,(card.suit),(card.cardNumber),A_NORMAL);
    	gameDisplay.updateScreen();
    	break;
	}
}

void Controller::displayHand(display &gameDisplay, Player &player){
	for(int i = 0; i<13; i++){
		if(player.getHand()[i].suit!=-1){
			userCardDisplay(gameDisplay, i, player.getHand()[i]);
		//sleep(300);
		}
	}
}

void Controller::displayPassCards(display &gameDisplay, Player &player){
	for(int i = 0; i<3; i++){
		userCardDisplay(gameDisplay, i, player.getCardsPassed()[i]);
		//usleep(300000);
	}
	for(int i = 3; i<13; i++){
		gameDisplay.eraseBox(player.getHand()[i].xPosition, player.getHand()[i].yPosition, 6, 5);
		//usleep(300000);
	}
}


void Controller::displayLastFourTrickPileCards(display &gameDisplay, Player &player){
	if(player.getNumberOfTrickPileCards()>3){
		for(int i = 0; i<4; i++){
			userCardDisplay(gameDisplay, i, player.getTrickPile()[player.getNumberOfTrickPileCards()-i-1]);
			//usleep(300000);
		}
		for(int i = 4; i<13; i++){
			gameDisplay.eraseBox((i*6+1),18, 6, 5);
			//usleep(300000);
		}
	}
	else displayHand(gameDisplay, player);
	gameDisplay.updateScreen();
}

void Controller::eraseFirstFourHandCards(display &gameDisplay){

	for(int i = 0; i<4; i++){
		gameDisplay.eraseBox((i*6+1), 18, 6, 5);
			//usleep(300000);
	}

	//else displayHand(gameDisplay, player);
	gameDisplay.updateScreen();
}

//this function moves an AI card from its hand array to the table array and displays it in the middle of the table
bool Controller::moveAICard(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb){
	for(int i = 0; i<13; i++){
		if((ai.chooseTrickCardEasy(zeRules, hb).suit == player.getHand()[i].suit)&&(ai.chooseTrickCardEasy(zeRules, hb).cardNumber == player.getHand()[i].cardNumber)){
			cardUserTrick(gameDisplay, player.getHand()[i], player.getPlayerNumber());
			trickCardsOnTable[player.getPlayerNumber()] = player.getHand()[i];
			player.setNullHandCard(i);
			return true;
		}
	}
	return false;
}

bool Controller::moveAICardDumb(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb){


	if(zeRules.checkIfValidCard(player.getHand()[player.getAIplaceHolder()], hb, player)){
		cardUserTrick(gameDisplay, player.getHand()[player.getAIplaceHolder()], player.getPlayerNumber());
		trickCardsOnTable[player.getPlayerNumber()] = player.getHand()[player.getAIplaceHolder()];
		player.setNullHandCard(player.getAIplaceHolder());
		player.incrementAIPlaceHolder();
		return true;
	}
	else{
		player.incrementAIPlaceHolder();
		return false;
	}
}

//moves the chosen pass cards from the AI's hand to the AI's pass cards array
void Controller::moveAIPassCards(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb){
	Card *passes = ai.choosePassCards();
	//player.setPassArray(passes);

	player.setCardsPassed(0,passes[0]);
	player.setCardsPassed(1,passes[1]);
	player.setCardsPassed(2,passes[2]);

	for(int j = 0; j<3; j++){
		for(int i = 0; i<13; i++){
			if(player.getHand()[i].deckNumber == passes[j].deckNumber){
				//player.setPassArray(passes[j]);
				player.setNullHandCard(i);
				sortHandBubble(player);
			}
		}
	}
}

void Controller::moveAIPassCardsDumb(Player &player, display &gameDisplay, AI &ai, Rules zeRules, theGauvin &hb){
	//Card *passes = ai.choosePassCards();
	//player.setPassArray(passes);

	player.setCardsPassed(0,player.getHand()[0]);
	player.setCardsPassed(1,player.getHand()[1]);
	player.setCardsPassed(2,player.getHand()[2]);

	player.setNullHandCard(0);
	player.setNullHandCard(1);
	player.setNullHandCard(2);

	//return true;
}
 
//takes in a location clicked by the user and returns true if it matches a card
bool Controller::moveUserCard(display &gameDisplay, Player &player, int clickX, int clickY, Rules rules, theGauvin &hb){
	for(int i = 0; i<13; i++){//change this when we figure out how we are going to delete the cards
		if(player.getHand()[i].yPosition >= 0 || player.getHand()[i].xPosition >= 0){
		//check if the click matches one in the players hand on the screen
			if( (clickX >= (player.getHand())[i].xPosition && clickX<((player.getHand())[i].xPosition+6)) 
				&& (clickY >= (player.getHand())[i].yPosition && clickY<((player.getHand())[i].yPosition+5) )){
				if(rules.checkIfValidCard(player.getHand()[i], hb, player)){
				gameDisplay.eraseBox(player.getHand()[i].xPosition, player.getHand()[i].yPosition, 6, 5);
				
				//also delete from the player's hand and put in trick pile
				//draw the card in the trick pile
				cardUserTrick(gameDisplay, player.getHand()[i], 1);
				
				trickCardsOnTable[1] = player.getHand()[i];
				trickCardsOnTable[1].xPosition=-1;
				trickCardsOnTable[1].yPosition=-1;
				player.setNullHandCard(i);
				
				//set the card struct's xPostion and yPosition to 37, 13 respectively
				return true;
				}

				else{
					stringstream messageString;
					messageString.str("");
					messageString << "Invalid card. Pick another card to play for the trick";
					gameDisplay.bannerTop(messageString.str());
					//userPlayTrickCard(gameDisplay, player, rules, hb);
					return false;
				}
			}
		}
	}
	return false;
}

//returns the array of cards that are on the table for the current trick
Card* Controller::getTrickCardsOnTable(){
	return trickCardsOnTable;
}
//manually changes turn state
void Controller::changeTurnState(theGauvin &hb, int turn){
    hb.currentTurnState = turn;
}

//manually change pass state
void Controller::changePassState(theGauvin &hb, int pass){
        hb.currentPassState = pass;
}

//automatically change pass state and return the pass state it is changed to
void Controller::advancePassState(theGauvin &hb){
    switch(hb.currentPassState){
        case LEFT:
            hb.currentPassState = RIGHT;
            break;
        case RIGHT:
            hb.currentPassState = ACROSS;
            break;
        case ACROSS:
            hb.currentPassState = NOPASS;
            break;
        case NOPASS:
            hb.currentPassState = LEFT;
            break;
        default:
            break;
    }
    //return passState;
}
 //need to figure out a way to access the players without passing them in as arguments
//returns overall turn state depending on player's hands, won trick cards, etc.
int Controller::detectTurnState(Player p1, Player p2, Player p3, Player p4, theGauvin hb){
    if(!findInTrickPile(p1,HEARTS)&&!findInTrickPile(p2,HEARTS)&&!findInTrickPile(p3,HEARTS)&&!findInTrickPile(p4,HEARTS)) return UNBROKENHEARTS;   //unbroken: iterate through all players' trick piles; if there are no hearts in any of the piles, change state to "unbroken"
    if((hb.currentTurnState!=BROKENHEARTS) && (findInTrickPile(p1,HEARTS)||findInTrickPile(p2,HEARTS)||findInTrickPile(p3,HEARTS)||findInTrickPile(p4,HEARTS))){
    	return BROKENHEARTS;   //broken: iterate through all players' trick piles; if there are any hearts in any of the piles, change state to "broken"
    }
    //^ quit as soon as you encounter a heart
    //if(handEmpty(p1)&&handEmpty(p2)&&handEmpty(p3)&&handEmpty(p4)) return EMPTY;   //empty: iterate through all players' hands, if there are no cards in the hands then c state to "empty"
    if(isEmpty(p1,p2,p3,p4)){return EMPTY;}
    return hb.currentTurnState;
}

bool Controller::isEmpty(Player p1, Player p2, Player p3, Player p4){
	int totalCardsWon = 0;
	totalCardsWon = p1.getNumberOfTrickPileCards()+p2.getNumberOfTrickPileCards()+p3.getNumberOfTrickPileCards()+p4.getNumberOfTrickPileCards();
	if(totalCardsWon>=52){
		return true;
	}
	else
		return false;

}
bool Controller::handEmpty(Player thePlayer){
    for(int i = 0; i < 13; i++){
    	if(thePlayer.getHand()[i].cardNumber != -1){
    		return false;
    	}
    	//else return true;
    	//need to find a way to make a null card
		//if(thePlayer.getHand[i] != null) return false;
    }
    return true;
}

//returns true if specified suit is in the specified player's trickpile
bool Controller::findInTrickPile(Player thePlayer, int theSuit){
    //overload this method to find different things
    for(int i = 0; i <thePlayer.getNumberOfTrickPileCards(); i++){
        if((thePlayer.getTrickPile()[i]).suit == theSuit) return true;

    }
	return false;
}

/* fix by finding a way to compare two cards
//returns true if specified card is in the specified player's trickpile
bool Controller::findInTrickPile(Player thePlayer, Card theCard){
    //overload this method to find different things
    for(int i = 0; i <thePlayer.getNumberOfTrickPileCards(); i++){
		//need to find a way to compare cards
		//       if(((thePlayer.getTrickPile())[i]) == theCard) return true;
       // else return false;
    }
}
*/
 //returns true if specified card is in the specified player's trickpile
bool Controller::findInTrickPile(Player thePlayer, int theSuit, int theCardNumber){
    //overload this method to find different things
    for(int i = 0; i <thePlayer.getNumberOfTrickPileCards(); i++){
        if((thePlayer.getTrickPile()[i]).suit == theSuit && (thePlayer.getTrickPile()[i]).cardNumber == theCardNumber) return true;
    }
	return false;
}

/*Spades = 1, Hearts = 2, Clubs = 3, Diamonds = 4*/

//creates the 52 unique cards of a standard playing deck and filles the deck array
void Controller::initializeDeck(){
    for(int jj = 0; jj<52; jj++){
    	 if(jj==0){                      //fill and number the 13 clubs cards
    	    deck[jj].cardNumber= jj+1;
    	    deck[jj].suit= CLUBS;
    		deck[jj].xPosition = -1;
    		deck[jj].yPosition = -1;
    		deck[jj].penaltyValue = 0;
    		deck[jj].deckNumber = 12;
    	}
        if(jj>0 && jj<13){                      //fill and number the 13 clubs cards
            deck[jj].cardNumber= jj+1;
            deck[jj].suit= CLUBS;
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].penaltyValue = 0;
			deck[jj].deckNumber = jj-1;
        }
        if(jj==13){             //fill and number the 13 diamonds cards
            deck[jj].cardNumber= jj-12;
            deck[jj].suit= DIAMONDS;
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].penaltyValue = 0;
			deck[jj].deckNumber = 25;
        }
        if(jj>13 && jj<26){             //fill and number the 13 diamonds cards
            deck[jj].cardNumber= jj-12;
            deck[jj].suit= DIAMONDS;
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].penaltyValue = 0;
			deck[jj].deckNumber = jj-1;
        }
        if(jj==26){             //fill and number the 13 spades cards
            deck[jj].cardNumber= jj-25;
            deck[jj].suit= SPADES;
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
            //if(jj==37) deck[jj].penaltyValue=13;    //assign a pentaly value of 13 to the queen of spades
			deck[jj].penaltyValue = 0;
			deck[jj].deckNumber = 38;
		}
        if(jj>26 && jj<39){             //fill and number the 13 spades cards
            deck[jj].cardNumber= jj-25;
            deck[jj].suit= SPADES;
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].penaltyValue = 0;
            if(jj==37) deck[jj].penaltyValue=13;    //assign a pentaly value of 13 to the queen of spades
            deck[jj].deckNumber = jj-1;
		}
        if(jj==39){                      //fill and number the 13 hearts cards
            deck[jj].cardNumber= jj-38;
            deck[jj].suit= HEARTS;
            deck[jj].penaltyValue= 1;   //assign a pentalty point of one to each heart card
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].deckNumber = 51;
        }
        if(jj>39){                      //fill and number the 13 hearts cards
            deck[jj].cardNumber= jj-38;
            deck[jj].suit= HEARTS;
            deck[jj].penaltyValue= 1;   //assign a pentalty point of one to each heart card
			deck[jj].xPosition = -1;
			deck[jj].yPosition = -1;
			deck[jj].deckNumber = jj-1;
        }
    }
}

//iterates through deck and places each card in a random place in the deck
void Controller::shuffle()
{
    srand(time(NULL));
    for(int k = 0; k<52; k++)
    {
        int position = rand()%51;
        Card original = deck[k];
        deck[k] = deck[position];
        deck[position] = original;
    }
}

//shuffles then deals out the deck of 52 cards, 13 per player
void Controller::deal(Player &p1, Player &p2, Player &p3, Player &p4, theGauvin &hb){
    //TODO: are these actually pointers?!, delete cards from deck
    shuffle();
    //if(deck has 52 cards)
    int countDeck=51;
    while(countDeck>=0){            //place the next card from the top of the array into each player's hand in order
        for(int i=12; i>=0; i--){
        	deck[i].player=1;
            p1.populateHand(i,deck[countDeck]);
            countDeck--;

            deck[i].player=2;
            p2.populateHand(i,deck[countDeck]);
            countDeck--;

            deck[i].player=3;
            p3.populateHand(i,deck[countDeck]);
            countDeck--;

            deck[i].player=4;
            p4.populateHand(i,deck[countDeck]);
            countDeck--;
        }
    }
    changeTurnState(hb, PASS);
    /*else{
        return error message
    }
    */
}

Card* Controller::getTrickCards(){
    return trickCardsOnTable;
}


//consider revising to return a string rather than a player object
/*
Player Controller::getTrickOwner(){
    return trickOwner;
}
*/

//consider revising to return a string rather than a player object
/*
Player Controller::getTrickWinner(){
    return trickWinner;
}
*/

/*
Player whoWonTrick(){

}
*/

