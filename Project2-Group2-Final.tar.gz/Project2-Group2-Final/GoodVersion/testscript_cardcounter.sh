#!/bin/bash
####################################
# Card Counter automated testing script
# Author: Marco Chiang
####################################
make -f makefile_cardcounter 
for xx in `ls ./AutomatedTesting/testcases_cardcounter/*.txt`  		# Loops through input files
do
	echo \######################
	echo \# Running Testcase $xx
	echo \######################		
	cp $xx cardcounter_input.txt		 	# Copy current input file to cardcounter_input.txt
	./CardCounterTest > $xx.out 	           	# Redirect cardCounterTest output to file
	if diff $xx.out $xx.sol >/dev/null; then 	# If no differences between output and solution
	echo \## [PASSED] $xx				# then the result matches expected result
	else
		echo \## [FAILED] $xx			# If not then display
		diff $xx.out $xx.sol			# the differences
	fi
done
