#!/bin/bash
####################################
# GoFish automated testing script
####################################
make -f makefile_gofish 
for xx in `ls ./testcases_gofish/*.txt`  		# Loops through input files
do
	echo \######################
	echo \# Running Testcase $xx
	echo \######################		
	cp $xx gofish_input.txt		 	# Copy current input file to gofish_input.txt
	./GoFishTest > $xx.out 	           	# Redirect GoFishTest output to file
	if diff $xx.out $xx.sol >/dev/null; then 	# If no differences between output and solution
	echo \## [PASSED] $xx				# then the result matches expected result
	else
		echo \## [FAILED] $xx			# If not then display
		diff $xx.out $xx.sol			# the differences
	fi
done
