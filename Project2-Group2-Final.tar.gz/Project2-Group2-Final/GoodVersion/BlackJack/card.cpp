#include "Card.h"
#include <iostream>
#include <time.h>
#include <stdlib.h>

void Card::setCardValues(int cardSuit, int cardNum)
{
    // set the values
	suit = cardSuit;
	num = cardNum;
	switch (cardNum)
	{
		case 1: value = 11; break; //by default Ace=1
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10: value = cardNum; break;// 2 - 10 -> num = value
		case 11:
		case 12:
		case 13: value = 10; break;// J = Q = K = 10
		default: ;break;
	}
}

int Card::getCardSuit()
{
    return suit;
}

int Card::getCardNum()
{
    return num;
}

int Card::getCardValue()
{
    return value;
}

