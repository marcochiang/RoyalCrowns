#include "user.h"
#include "./../Bank.h"

user::user()
{

    //Initializes variables to zero

    handValue=0;
    handCount=-1;


    splitValue=0;
    splitCount=-1;

    money=0;
    moneyBet=0;
    insuranceBet=0;
    splitBet=0;

    isSplit=0;
}

user::~user()
{
    //dtor
}

void user::setMoney(int startMoney)   //Sets starting money
{
    money=startMoney;
	//theBank.getBet();		// Tracker
}

void user::getCard(Card thisCard)              //Adds card to hand
{
    handCount++;
    hand[handCount]=thisCard;
    evaluateHand();
}

void user::getSplitCard(Card thisCard)              //Adds card to splitHand
{
    splitCount++;
    handSplit[splitCount]=thisCard;
    evaluateSplitHand();
}

void user::setBet(int bet)            //Set moneyBet
{
    moneyBet=bet;
    money-=moneyBet;
}

void user::evaluateHand()
{
    handValue+=hand[handCount].getCardValue();
}

void user::evaluateSplitHand()
{
    splitValue+=handSplit[splitCount].getCardValue();
}


void user::hit()                          //Take another card from the Dealer     //Dont think i need this!!
{
    handCount++;                          //Increases count of Hand
//  hand[handCount]=Dealer.drawCard();    //Adds a Card to hand array

//  handValue=hand[].evaluate()
//  OR evaluateHand();?
}

void user::stand()        //Take no more cards
{
    //Do nothing?
}

void user::split()        //On first decision, if cards same value, create two hands
{
    handSplit[0]=hand[1];   //Put one card in second hand
    handValue/=2;           //handValue=handValue/2 because one card is taken away
    handCount--;            //Decrement count of Hand
    splitCount++;           //Increment count of handSplit
    money-=moneyBet;        //Decrement money by moneyBey
    splitBet=moneyBet;      //splitBet=moneyBet
    isSplit=1;
    evaluateSplitHand();
}

void user::doubleDown()   //Double bet, get exactly one more card
{
    money-=moneyBet;        //Decrease money
    moneyBet*=2;            //Double bet
}

void user::surrender()    //On first decision, can take back half bet and quit
{
    money+=moneyBet/2;
    moneyBet=0;
}

void user::insurance()    //If dealer's card is an Ace, user can make 2:1 bet that Dealer has blackjack
{
    insuranceBet=moneyBet;  //insuranceBet equal to moneyBet
    money-=moneyBet;        //Decrease money
}

int user::getMoney()      //Returns money
{
    return money;
}

int user::getMoneyBet()      //Returns money
{
    return moneyBet;
}

int user::getInsuranceBet()      //Returns money
{
    return insuranceBet;
}

int user::getSplitBet()      //Returns money
{
    return splitBet;
}

int user::getHandValue()      //Returns handValue
{
    return handValue;
}

int user::getHandCount()      //Returns handCount
{
    return handCount+1;
}

int user::getSplitValue()      //Returns splitValue
{
    return splitValue;
}

int user::getSplitCount()      //Returns splitValue
{
    return splitValue;
}

int user::getShowingCard()        //Returns dealer's face-up card to check if user can get insurance
{
    return hand[1].getCardNum();
}

Card user::getHiddenCard()	//Returns Card that was face down
{
	return hand[0];
}

Card user::getSplitCard()		//Returns card that goes to splitHand
{
	return hand[1];
}

int user::checkSplit()        //Returns 1 if user can split
{
    if (hand[0].getCardNum()==hand[1].getCardNum())
        return 1;
    else
        return 0;
}

int user::splitExists()
{
    return isSplit;
}

void user::payInsurance()     //If user wins insurance bet
{
    money+=insuranceBet;
}

void user::lost()           //LOSES: Lose moneyBet
{
    moneyBet=0;
}

void user::won()            //WON: Get double money back, reset moneyBet
{
    money+=moneyBet*2;
    moneyBet=0;
}

void user::lostSplit()           //LOSES: Lose SplitBet
{
    splitBet=0;
}

void user::wonSplit()            //WON: Get double money back, reset splitBet
{
    money+=splitBet*2;
    splitBet=0;
}

void user::reset()           //resets variables for new round
{
     //Initializes variables to zero
     //DOES NOT reset Money
    handValue=0;
    handCount=-1;

    splitValue=0;
    splitCount=-1;

    moneyBet=0;
    insuranceBet=0;
    splitBet=0;

    isSplit=0;
}
