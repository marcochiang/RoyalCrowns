// BlackJack launch mechanism

#ifndef BLACKJACK_H
#define BLACKJACK_H

#include "./../display.h"

class BlackJack
{
public:
	
	BlackJack();
	~BlackJack();
	int startBJ();
	void detectResize(int);
};

#endif
