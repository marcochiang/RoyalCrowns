/* Title: Project 2 ECE373 
 * 
 * BlackJack
 *
 * Joel Jean-Claude
 * Ousmane Mbaye
 * Jeremy Iken
 */
// Card tracker works 12/5/12
// Game does not exit on the first try. It will force a new round. After the user attempts to quit the 
// second time, the game returns to the main menu


#include "./../display.h"
#include <signal.h>
#include <ncurses.h>
#include <cstdlib>
#include <sstream>
#include "BlackJack.h"
#include "user.h"
#include "dealer.h"
#include <iostream>
#include <string>
#include "./../Advertisement.h"
#include "./../Bank.h"
#include "./../CardCounter.h"
#include "./../GameTimer.h"

// Card Tracker
extern CardCounter cardCounter;

// Bank Tracker
extern Bank theBank;

// Constructor
BlackJack::BlackJack()
{
  startBJ();
}



/* No Header file for this example driver artifact
 * function declaration here instead.
 */
// Signal Subroutine for Window Resize
//static void detectResize (int sig);
// stub artifact for what the game does when the screen resizes
//void stub_PrintResize(void);

// The gameDisplay object is global, because the static signal handler object
// needs to access the dynamic object.
display gameDisplay3;





int BlackJack::startBJ(void){



	// various variable declarations, not used
/*	char key;
	int cardX = 0;
	int cardY = 0;
	int suit = 0;
	int number = 0;

	int dragX = 0;
	int dragY = 0;
*/
	// enable a interrupt triggered on a window resize
	// signal(SIGWINCH, detectResize); // enable the window resize signal



    ////////////////////////////////////////////////////////////////
    //Player PLR and CPTR (essentially the dealer player) declared//
    //Dealer DLR (essentially the House) declared                 //
    //Player is given $100                                        //
    //Playing loop begins                                         //
    ////////////////////////////////////////////////////////////////

    user PLR;
    user CPTR;
    Dealer DLR;



PLR.setMoney(100); //Sets starting money to 100


int another;     //Gets used at end of the loop asks if player wants to play another hand

for (;;)            //Front screen shows rules
{

	mvprintw(15,30,"WELCOME TO THE $10 BLACKJACK TABLE!");
	mvprintw(18,35,"RULES:");
	mvprintw(20,35,"Start with $100");
	mvprintw(22,35,"$10 Initial Bet");
	mvprintw(24,35,"Tie goes to the House");
	mvprintw(30,35,"Press space to continue");

		if (gameDisplay3.captureInput()!=0)
		break;
}



do{


	gameDisplay3.eraseBox(0,0,gameDisplay3.getCols(), gameDisplay3.getLines());		//Erase screen for new game


// using a stringstream rather than a string to make making the banner easier
	//stringstream messageString;

// Advertisement Display
  Advertisement advert;
  
  gameDisplay3.bannerTop(advert.getAdvert());

// Transition Window
	stringstream prompt;
	mvprintw(23, 2, "Enter a new bet, then press Enter (Input will not be displayed)");
	prompt.str("");
	gameDisplay3.updateScreen();




	int CPTRx=80;
	int CPTRy=10;
	int PLRx=80;
	int PLRy=30;
	int SPLITx=80;
	int SPLITy=36;
	int textx=10;
	int texty=7;

    /////////////////////////////////////////////
    //Deck is initalized and shuffled          //
    //player and Computer values are reset     //
    //This is for when a second round is played//
    /////////////////////////////////////////////

    DLR.initialize();
    DLR.shuffle();

    PLR.reset();
    CPTR.reset();

	gameDisplay3.eraseBox(0,0,gameDisplay3.getCols(), gameDisplay3.getLines());	//Erase screen again to fix bug?

    /////////////////////////////////////////
    //Bet of $10 taken                     //
    //Cards are delt to player and computer//
    //Those cards are displayed on screen  //
    /////////////////////////////////////////



	// Prompt player to set a bet
gameDisplay3.bannerTop("Place a bet to play a hand. Please enter a value (0 if no bet), then hit enter.");
	theBank.getBet();


	// Default betting system. Will not be sent back to new tracking system.
	//Decided to just make it a $10 table//
	int betMoney=10;
        PLR.setBet(betMoney);


	stringstream messageString;
	messageString.str("");
	messageString<<"Bank: $"<<PLR.getMoney()<<"    Bet: $"<<PLR.getMoneyBet()<<"    Insurance: $"<<PLR.getInsuranceBet()<<"    Split Bet: $:"<<PLR.getSplitBet();
	gameDisplay3.bannerTop(messageString.str());



    gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
    PLRx+=6;
    PLR.getCard(DLR.getTopCard());
	cardCounter.blackJackCardCount++;	// Tracker

	gameDisplay3.displayCard(CPTRx,CPTRy,0,DLR.showTopCard().getCardNum(),A_BOLD);
    CPTRx+=6;
    CPTR.getCard(DLR.getTopCard());

    gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
    PLRx+=6;
    PLR.getCard(DLR.getTopCard());

    gameDisplay3.displayCard(CPTRx,CPTRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
    CPTRx+=6;
    CPTR.getCard(DLR.getTopCard());


    /////////////////////////////////////////////////////////////////
    //If Computer is showing an Ace, then player can take insurance//
    /////////////////////////////////////////////////////////////////



    int isInsured=0;
	if (CPTR.getShowingCard()==1)
	{
	for (;;)
		{
		mvprintw(texty,textx,"Do you want insurance? (y/n)");
		if (gameDisplay3.captureInput()=='y')
		{
			PLR.insurance();
			isInsured=1;
			texty+=2;
			break;
		}
		else if (gameDisplay3.captureInput()=='n')
		{
			texty+=2;
			break;
		}
		}
	}

                        //Banner set

	messageString.str("");
	messageString<<"Bank: $"<<PLR.getMoney()<<"    Bet: $"<<PLR.getMoneyBet()<<"    Insurance: $"<<PLR.getInsuranceBet()<<"    Split Bet: $:"<<PLR.getSplitBet();
	gameDisplay3.bannerTop(messageString.str());

    ////////////////////////////////////////
    //Checks if player can split          //
    //Then asks player what he wants to do//
    ////////////////////////////////////////


    int option=0;           //hit(1), stand(2), double down(3), surrender(4), or split(5)
    int winOrLose=0;        //Win=1, Lose=2, inProgress=0
    int winOrLoseSplit=0;   //Win=1, Lose=2, inProgress=0
    int surrendered=0;      //if 1, then player surrendered


for (;;)
{

    do{

    if (PLR.checkSplit()==1)
    {

        mvprintw(texty,textx,"Do you want to hit(1), stand(2), double down(3), surrender(4), or split(5)?");
		option=0;
		option=(gameDisplay3.captureInput()-48);
    }

    else
    {
		mvprintw(texty,textx,"Do you want to hit(1), stand(2), double down(3), or surrender(4)?");
		option=0;
		option=(gameDisplay3.captureInput()-48);
    }

    } while (!(option==1 || option==2 || option==3 || option==4 || option==5));     //Makes sure player chooses an option
	texty+=2;
	break;

}


    //////////////////////////////////////////
    //Case statement to evaluate each option//
    //////////////////////////////////////////


    switch (option)
    {
        case 1:     //HIT: player gets another card
			gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
			PLRx+=6;
			PLR.getCard(DLR.getTopCard());
            break;

        case 2:     //STAND: player's turn is over
            break;

        case 3:     //DOUBLEDOWN: Bet is doubled and player gets one more card
            PLR.doubleDown();

			gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
			PLRx+=6;
			PLR.getCard(DLR.getTopCard());
            break;

        case 4:     //SURRENDER: player quits but gets half his bet back.
            PLR.surrender();
            winOrLose=2;
            surrendered=1;
            break;

        case 5:     //SPLIT: player splits hand and gets a new card on each hand
            PLR.split();
			PLRx-=6;

			gameDisplay3.displayCard(SPLITx,SPLITy,PLR.getSplitCard().getCardSuit(),PLR.getSplitCard().getCardNum(),A_BOLD);
			SPLITx+=6;

			gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
			PLRx+=6;
			PLR.getCard(DLR.getTopCard());

			gameDisplay3.displayCard(SPLITx,SPLITy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
			SPLITx+=6;
			PLR.getSplitCard(DLR.getTopCard());
            break;

        default:    //ERROR?
        cout << "ERROR!!!!!!!!!!!!!";
        break;
    }

                        //Updates Banner
	messageString.str("");
	messageString<<"Bank: $"<<PLR.getMoney()<<"    Bet: $"<<PLR.getMoneyBet()<<"    Insurance: $"<<PLR.getInsuranceBet()<<"    Split Bet: $:"<<PLR.getSplitBet();
	gameDisplay3.bannerTop(messageString.str());


    ///////////////////////////////////////
    //Checks if player busted either hand//
    ///////////////////////////////////////


    if (PLR.getHandValue()>21)      //If over 21, you lose
    winOrLose=2;
    if (PLR.getSplitValue()>21)     //checks if splitHand is a bust
    winOrLoseSplit=2;




    //////////////////////////////////
    //Switch statment for first hand//
    //////////////////////////////////


    if ((winOrLose!=2))     //If you didnt lose your first hand, ask if player wants to hit again
    {
    switch (option)
    {
        ////////////////////////////////////////////////////////////
        //HIT: Keep hitting until player chooses to stand or busts//
        ////////////////////////////////////////////////////////////

        case 5:         //same thing as Case 1 if player split
        case 1:

		for (;;)
		{

            do {
			mvprintw(texty,textx,"Do you want to hit(1) or stand(2)");
			option=0;
			option=((gameDisplay3.captureInput())-48);
            if (option==1)
            {
				gameDisplay3.displayCard(PLRx,PLRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
				PLRx+=6;
				PLR.getCard(DLR.getTopCard());

                if (PLR.getHandValue()>21)
                    winOrLose=2;
            }
            } while (((option==1)||(option==-48))&&(winOrLose!=2));

			texty+=2;
			break;
		}

        break;
        default:
        break;
    }
    }


    //////////////////////////////////
    //Evaluates Split hand if needed//
    //////////////////////////////////

    if (PLR.splitExists()==1)
    {
        if (winOrLoseSplit!=2)
        {
		for (;;)
		{

        do {

			mvprintw(texty,textx,"Do you want to hit(1) or stand(2) on your second hand?");
            option=0;
			option=(gameDisplay3.captureInput()-48);
            if (option==1)
            {
				gameDisplay3.displayCard(SPLITx,SPLITy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
				SPLITx+=6;
				PLR.getSplitCard(DLR.getTopCard());
                if (PLR.getSplitValue()>21)
                    winOrLoseSplit=2;
            }
            } while (((option==1)||(option==-48))&&(winOrLoseSplit!=2));
			texty+=2;
			break;

        }
		}
    }

        ///////////////////////////////////////////////////////////////
        //STAND/DOUBLEDOWN: Evaluate Computer hand, compare vs player//
        ///////////////////////////////////////////////////////////////

    if (((winOrLose!=2)&&(surrendered!=1))||(isInsured==1))               //If you didn't surrender and didnt bust, OR you bought insurance
    {
			gameDisplay3.displayCard(80,CPTRy,CPTR.getHiddenCard().getCardSuit(),CPTR.getHiddenCard().getCardNum(),A_BOLD);
        while (CPTR.getHandValue()<17)                 //If computer's hand is less than 17, he hits
        {
			gameDisplay3.displayCard(CPTRx,CPTRy,DLR.showTopCard().getCardSuit(),DLR.showTopCard().getCardNum(),A_BOLD);
			CPTRx+=6;
			CPTR.getCard(DLR.getTopCard());
        }
        if (((CPTR.getHandValue()>21))||((PLR.getHandValue())>(CPTR.getHandValue()))) //if CPTR>21 OR PLR>CPTR, then player Wins
            winOrLose=1;    //player Wins
        else
            winOrLose=2;    //player Loses
    }


    if ((PLR.splitExists()==1)&&(winOrLoseSplit!=2))      //If player has a split hand and it didnt bust
    {
        if (((CPTR.getHandValue()>21))||((PLR.getSplitValue())>(CPTR.getHandValue()))) //if CPTR>21 OR PLR>CPTR, then player Wins
            winOrLoseSplit=1;    //player Wins
        else
            winOrLoseSplit=2;    //player Loses
    }




    /////////////////////////////////////////////////////
    //Outputs whether player lost or won or surrendered//
    /////////////////////////////////////////////////////


    if (surrendered==1)
    {
        mvprintw(30,0,"You surrendered");
    }
    else if (winOrLose==1)
    {
        mvprintw(30,0,"You WIN!!!");
        PLR.won();
	theBank.winBet(); // Tracker
    }
    else if (winOrLose==2)
    {
        mvprintw(30,0,"You lose :(");
        PLR.lost();
	theBank.lossBet(); // Tracker
    }



    if (PLR.splitExists())
    {

        if (winOrLoseSplit==1)
        {
			mvprintw(35,0,"You won your second hand");
            PLR.wonSplit();
        }
        else if (winOrLoseSplit==2)
        {
			mvprintw(35,0,"You lose your second hand");
            PLR.lostSplit();
        }

    }

            //Pays out insurance if needed

    if ((CPTR.getHandCount()==2)&&(CPTR.getHandValue()==21)&&(isInsured==1))
    {
        PLR.payInsurance();
    }

                            //Updates banner
	messageString.str("");
	messageString<<"Bank: $"<<PLR.getMoney()<<"    Bet: $"<<PLR.getMoneyBet()<<"    Insurance: $"<<PLR.getInsuranceBet()<<"    Split Bet: $:"<<PLR.getSplitBet();
	gameDisplay3.bannerTop(messageString.str());


        ///////////////////////////////////////////
        //Asks if player would like to play again//
        ///////////////////////////////////////////

for (;;)
{
			mvprintw(40,0,"Would you like to play another hand? (y/n)");
			another=0;
			another=(gameDisplay3.captureInput());
			if ((another=='y')||(another=='n'))
			break;
	}
} while ((another=='y') && (PLR.getMoney()>=10));

	gameDisplay3.eraseBox(0,0,gameDisplay3.getCols(), gameDisplay3.getLines());		//Erase screen
	gameDisplay3.eraseBox(0,0,gameDisplay3.getCols(), gameDisplay3.getLines());		//Erase screen again to fix bug?

for (;;)
{
		stringstream Money;
		Money.str("");
	//	Money << "Final Bank account: $" << PLR.getMoney();
		Money << "Final Bank account: $" << theBank.bank;
		mvprintw(41,20,Money.str().c_str());
		mvprintw(43,20,"Thank you for playing! Goodbye.");
			if (gameDisplay3.captureInput()!=0)
		break;
}





/* You can uncomment and change the colors for various cards here*/
//    init_pair(1, COLOR_CYAN, COLOR_BLACK); // for card outline
//    init_pair(2, COLOR_BLUE, COLOR_BLACK); // for spades and clubs
//    init_pair(3, COLOR_RED, COLOR_BLACK);  // for hearts and diamonds
//    init_pair(4, COLOR_GREEN, COLOR_BLACK); // for turned over card
//    init_pair(5, COLOR_GREEN, COLOR_BLACK); // for box drawing
//    init_pair(6, COLOR_GREEN, COLOR_BLACK); // for banner display

	return 0;
}


// Destructor
BlackJack::~BlackJack()
{
}

