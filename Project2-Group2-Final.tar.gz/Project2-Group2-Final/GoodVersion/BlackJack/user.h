#ifndef USER_H
#define USER_H
#include "dealer.h"


    //////////////////////////
    //Jeremy Iken ECE373    //
    //Blackjack Player class//
    //////////////////////////

class user
{
public:

    user();           //Constructor
    virtual ~user();  //Virtual Deconstructor

    //Function defined in user.cpp
    void setMoney(int);
    void getCard(Card);
    void getSplitCard(Card);
    void setBet(int);
    void evaluateHand();
    void evaluateSplitHand();

    void hit();
    void stand();
    void split();
    void doubleDown();
    void surrender();
    void insurance();

    int getMoney();
    int getMoneyBet();
    int getInsuranceBet();
    int getSplitBet();

    int getHandValue();
    int getHandCount();
    int getSplitValue();
    int getSplitCount();

    int getShowingCard();      //Only for dealer
	Card getHiddenCard();		//Only for dealer
	Card getSplitCard();		//for user when he splits
    int checkSplit();          //Returns 1 if user can split his hand
    int splitExists();          //Returns 1 if user split cards
    void payInsurance();

    void lost();
    void won();
    void lostSplit();
    void wonSplit();

    void reset();

protected:

private:

    Card hand[5];       //Array of 5 Cards, as user's hand
    int handValue;      //Value of hand
    int handCount;      //Card count of hand

    Card handSplit[5];  //Array of 5 Cards, as user's splitting hand
    int splitValue;     //Value of handSplit
    int splitCount;     //Card count of handSplit

    int money;          //Money user owns
    int moneyBet;       //Money user bet
    int insuranceBet;   //Money user bet on insurance
    int splitBet;       //Money user bet on split hand

    int isSplit;    //0 is no splitHand, 1 is there is a splitHand
};

#endif // user_H
