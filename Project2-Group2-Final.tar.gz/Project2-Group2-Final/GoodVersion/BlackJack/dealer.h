#ifndef DEALER_H
#define DEALER_H

/* Ousmane Mbaye ECE373
 * BlackJack Project: Dealer
 * Filename: blackjack.h
 *
 */

#define DECK_SIZE 52

// Card Class
class Card
{
  public:
	//Card(int cardSuit, int cardNum);
	//~Card(void);
    void setCardValues(int cardSuit, int cardNum);
	int getCardSuit();
	int getCardNum();
	int getCardValue();
  private:
	int suit, num, value;
};

//Dealer Class
class Dealer
{
    public:
    Dealer();
    void initialize();             //initialize deck
    void shuffle();
    Card getTopCard(); //give the card on the top of the deck
    Card showTopCard();

    private:
    Card theDeck[DECK_SIZE];   //array of 52 cards
    int topCard;        //Top card to be dealt
};



void testCardClass();// test card class
void testDeckClass();//tst deck class






/*
class dealer
{
    public:
        dealer();
        virtual ~dealer();
    protected:
    private:
};
*/

#endif // DEALER_H
