/*
 * Menu.h
 *
 *  Created on: Nov 20, 2012
 *      Author: john
 */

#ifndef MENU_H_
#define MENU_H_

class Menu {
public:
	Menu();
	virtual ~Menu();
};

#endif /* MENU_H_ */
