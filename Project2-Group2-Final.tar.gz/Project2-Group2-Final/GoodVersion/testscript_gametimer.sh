#!/bin/bash
####################################
# Game Timer automated testing script
# Author: Marco Chiang
####################################
make -f makefile_gametimer 
for xx in `ls ./AutomatedTesting/testcases_gametimer/*.txt`  		# Loops through input files
do
	echo \######################
	echo \# Running Testcase $xx
	echo \######################		
	cp $xx gametimer_input.txt		 	# Copy current input file to gametimer_input.txt
	./GameTimerTest > $xx.out 	           	# Redirect GameTimerTest output to file
	if diff $xx.out $xx.sol >/dev/null; then 	# If no differences between output and solution
	echo \## [PASSED] $xx				# then the result matches expected result
	else
		echo \## [FAILED] $xx			# If not then display
		diff $xx.out $xx.sol			# the differences
	fi
done
