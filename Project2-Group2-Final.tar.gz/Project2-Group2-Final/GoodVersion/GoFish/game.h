/*
 * Game.h
 *
 *  Created on: Oct 18, 2012
 *      Author: marcochiang
 */

#ifndef GAME_H_
#define GAME_H_

#include <string>
#include <vector>
#include "deck.h"
#include "player.h"


class game {
public:
	game();
	deck::deck getDeck();
	card::card drawCard();
	void createGame();
	void addPlayer(player::player p);
	void dealCards();
	void addCard(card::card c, int player);
	card::card takeCard(int faceVal, int player);
	int getPlayerCount();
	int highestScore();
	player::player getPlayer(int x);

private:
	std::string _name;
	deck _deck;
	std::vector<player> _playerList;
};

#endif
