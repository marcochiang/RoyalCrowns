/*
 * GoFish.h
 *
 *  Created on: Nov 28, 2012
 *      Author: marcochiang
 */

#ifndef GOFISH_H_
#define GOFISH_H_

#include "./../display.h"
#include "./../GameTimer.h"
#include <vector>


class GoFish
{
public:
	GoFish();
	int startGoFish(GameTimer &timer);
	int determineWinner();
	int Winner;
	display gameDisplay2;
	game currentGame;
	void displayHand(std::vector<card> input);
	void displayDeck(deck input);
	void drawDeck(int comps);
	void drawSelection();
	void updateScore(int comps);
	bool isGameOver();
};
#endif /* GOFISH_H_ */
