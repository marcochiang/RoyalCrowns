#include <list>
#include <sstream>
#include "player.h"

//Player class
//Created 10/10/2012
//Author: Justin Mills

//Constructor
player::player(std::string name, int x, int y)
{
	player::_name = name;
	player::_score = 0;
	player::_xScore = x;
	player::_yScore = y;
}

//Constructor
player::player(std::string name, int x, int y, int scoreX, int scoreY)
{
	player::_name = name;
	player::_score = 0;
	player::_xCoord = x;
	player::_yCoord = y;
	player::_xScore = scoreX;
	player::_yScore = scoreY;
}

/**
 * Add a card to player's hand.
 */
void player::addCard(card::card c)
{
	player::_hand.push_back(c);
	hasDuplicate();
}

//Returns the player's score
int player::getScoreVal()
{
	return player::_score;
}

//Returns the player's name
std::string player::getName()
{
	return player::_name;
}

//Returns the string representation of the score to display.
std::string player::getScore()
{
	std::stringstream messageString;
	messageString.str("");
	messageString << "Score: " << player::_score << " Hand Size: " << player::_hand.size();
	return messageString.str();
}

//Gets a random card from a player's hand.
card::card player::getRandomCard()
{
	srand(time(NULL)); //Seed the random number generator
	random_shuffle(player::_hand.begin(), player::_hand.end()); //Perform shuffle
	return player::_hand.at(0);
}

/**
 * Returns true if a player contains that card in their hand.  False otherwise.  Will be used such
 * that if returns true, then the takecard method should be subsequently called.  Could get rid of this
 * function and have takecard return null if nothing found, but may be more error prone and ugly.
 */
bool player::haveCard(int faceVal)
{
	unsigned int x = 0;

	for(; x < player::_hand.size(); x++)
	{
		if(player::_hand.at(x).getFace() == faceVal)
		{
			return true;
		}
	}
	return false;
}

/**
 * Discards a card with the given face value and then returns it so that another player
 * can add it to their hand.
 */
card::card player::takeCard(int faceVal)
{
	unsigned int x = 0;
	card returncard;

	for(; x < player::_hand.size(); x++ ) //Search for card
	{
		if(player::_hand.at(x).getFace() == faceVal)
		{
			returncard = player::_hand.at(x);
			player::_hand.erase(player::_hand.begin()+x);
			break;
		}
	}

	return returncard;
}

/**
 * Checks if there are any duplicates in the player's hand.  If so, discards the two cards and
 * returns true.  Will have to loop until returns false to remove all duplicates.
 */
bool player::hasDuplicate()
{
	card::card rmv1;
	card::card rmv2;
	unsigned int x = 0;

	for(; x < player::_hand.size(); x++ )
	{
		unsigned int y = x+1;
		card::card temp1 = player::_hand.at(x);
		for(; y < player::_hand.size(); y++ )
		{
			card::card temp2 = player::_hand.at(y);
			if(temp2.getFace() == temp1.getFace() && temp1.getSuit() != temp2.getSuit())
			{
				player::_hand.erase(player::_hand.begin()+x);
				player::_hand.erase(player::_hand.begin()+y);
				player::_score++;
				return true;
			}
		}
	}
	return false;
}

//Returns the player's hand.
std::vector<card::card> player::getHand()
{
	return player::_hand;
}

//Sets the player's hand.
void player::setHand(std::vector<card::card> set)
{
	player::_hand = set;
}

//Takes in an x and y screen coordinate parsed in from the display class and maps that to a card in the player's
//hand to detect whether a card was clicked or not.  Returns the cards value if clicked, otherwise -1.
int player::coordsToCard(int x, int y)
{
	int size = player::_hand.size();
	if(x >= 17 && x <= 22 && y >= 13 && y <= 17)
	{
		if(size >= 1)
		{
			return player::_hand.at(0).getFace();
		}
		else
			return -1;
	}
	else if(x >= 24 && x <= 29 && y >= 13 && y <= 17)
	{
		if(size >= 2)
		{
			return player::_hand.at(1).getFace();
		}
		else
			return -1;
	}
	else if(x >= 31 && x <= 36 && y >= 13 && y <= 17)
	{
		if(size >= 3)
		{
			return player::_hand.at(2).getFace();
		}
		else
			return -1;
	}
	else if(x >= 38 && x <= 43 && y >= 13 && y <= 17)
	{
		if(size >= 4)
		{
			return player::_hand.at(3).getFace();
		}
		else
			return -1;
	}
	else if(x >= 45 && x <= 50 && y >= 13 && y <= 17)
	{
		if(size >= 5)
		{
			return player::_hand.at(4).getFace();
		}
		else
			return -1;
	}
	else if(x >= 52 && x <= 57 && y >= 13 && y <= 17)
	{
		if(size >= 6)
		{
			return player::_hand.at(5).getFace();
		}
		else
			return -1;
	}
	else if(x >= 59 && x <= 64 && y >= 13 && y <= 17)
	{
		if(size >= 7)
		{
			return player::_hand.at(6).getFace();
		}
		else
			return -1;
	}
	else if(x >= 17 && x <= 22 && y >= 18 && y <= 22)
	{
		if(size >= 8)
		{
			return player::_hand.at(7).getFace();
		}
		else
			return -1;
	}
	else if(x >= 24 && x <= 29 && y >= 18 && y <= 22)
	{
		if(size >= 9)
		{
			return player::_hand.at(8).getFace();
		}
		else
			return -1;
	}
	else if(x >= 31 && x <= 36 && y >= 18 && y <= 22)
	{
		if(size >= 10)
		{
			return player::_hand.at(9).getFace();
		}
		else
			return -1;
	}
	else if(x >= 38 && x <= 43 && y >= 18 && y <= 22)
	{
		if(size >= 11)
		{
			return player::_hand.at(10).getFace();
		}
		else
			return -1;
	}
	else if(x >= 45 && x <= 50 && y >= 18 && y <= 22)
	{
		if(size >= 12)
		{
			return player::_hand.at(11).getFace();
		}
		else
			return -1;
	}
	else if(x >= 52 && x <= 57 && y >= 18 && y <= 22)
	{
		if(size >= 13)
		{
			return player::_hand.at(12).getFace();
		}
		else
			return -1;
	}
	else
		return -1;
}
