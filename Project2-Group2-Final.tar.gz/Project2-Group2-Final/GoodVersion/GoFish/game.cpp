/*======================================================================================================
 * Marco Chiang, Student ID: 25234184
 * ECE 373: Software Intensive Engineering
 * Project 1 - Go Fish
 * Description: The gameClass creates a new game and uses other classes to add players, add deck, and deal.
 * This mimicks the duties of a card dealer.
 *======================================================================================================
 */
//#include <iostream>
#include "game.h"

/**
 * Will create a new game with the specified number of players as well as the name of the player playing.
 */

game::game()
{
	createGame();
}

//Starts the game by dealing out the cards for the players.
void game::createGame()
{
	dealCards();
}

//Draws a card from the deck.
card::card game::drawCard()
{
	return _deck.dealCard();
}

//Returns the player with the highest score.
int game::highestScore()
{
	unsigned int x = 0;
	int highest = 0;
	int index = 0;
	for(; x < game::_playerList.size(); x++)
	{
		if(game::_playerList.at(x).getScoreVal() > highest)
		{
			highest = game::_playerList.at(x).getScoreVal();
			index = x;
		}
	}
	return index;
}

//Adds a card to the respective player's hand.
void game::addCard(card::card c, int player)
{
	game::_playerList.at(player).addCard(c);
}

//Takes a card from the respective player's hand.
card::card game::takeCard(int faceVal, int player)
{
	return game::_playerList.at(player).takeCard(faceVal);
}

/**
 * Adds a player to the list of players.
 */
void game::addPlayer(player::player p)
{
	game::_playerList.push_back(p);
}

//Returns a specific player.
player::player game::getPlayer(int x)
{
	return game::_playerList.at(x);
}

//Returns the deck.
deck::deck game::getDeck()
{
	return _deck;
}

//Returns the player count.
int game::getPlayerCount()
{
	return game::_playerList.size();
}

//Deals 7 cards to each player if <= 2 players. 5 Cards if > 3 or 4(max)
void game::dealCards()
{
	if(game::_playerList.size() <= 2)
	{
		unsigned int x = 0;
		for(; x < game::_playerList.size(); x++)
		{
			int y = 0;
			for(; y < 7; y++)
			{
				game::_playerList.at(x).addCard(drawCard());
			}
		}
	}
	else
	{
		unsigned int x = 0;
		for(; x < game::_playerList.size(); x++)
		{
			int y = 0;
			for(; y < 5; y++)
			{
				game::_playerList.at(x).addCard(drawCard());
			}
		}
	}
	//used to debug how many cards were drawn

}
