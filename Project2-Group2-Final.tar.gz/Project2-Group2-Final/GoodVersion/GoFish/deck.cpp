/*
 * Deck.cpp
 *
 *  Created on: Oct 11, 2012
 *      Author: Trevor Elkins
 */

#include <iostream>
#include <algorithm>
#include <vector>
#include "deck.h"
#include <time.h>
#include <list>
#include "./../CardCounter.h"

extern CardCounter cardCounter;

using namespace std;

deck::deck()
{
	this->newDeck();
}

/**
 * Clears any previous deck being used.  Creates all 52 cards again and then randomly shuffles the deck.
 *
 * Returns void.
 */
void deck::newDeck()
{
	deck::_deck.clear(); //Destroy previous deck

	//Create new set of cards in order
	for(int x = 1; x < 14; x++)
	{
		for(int y = 1; y < 5; y++)
		{
			card temp(y,x);
			deck::_deck.push_back(temp);
		}
	}

	srand(time(NULL)); //Seed the random number generator
	random_shuffle(deck::_deck.begin(), deck::_deck.end()); //Perform shuffle
}

//Returns if the deck is empty or not.
bool deck::isEmpty()
{
	if(_deck.size()==0)
		return true;
	else
		return false;
}
/**
 * Pops the last Card object in the deck and returns it.
 *
 * Returns the popped Card.
 */
card deck::dealCard()
{
	card temp = deck::_deck.back();
	deck::_deck.pop_back();
	cardCounter.goFishCardCount++;
	return temp;
}

/**
 * Gets the current size of the deck.
 *
 * Returns the size of the vector object.
 */
int deck::getSize()
{
	return deck::_deck.size();
}
