/* Title: Project 1 ECE373 Driver Class for GoFish
 * Author: Trevor Elkins, Marco Chiang, Liyan Tang, Justin Mills, and John Shields.
 * Description: Runs the GoFish game.
 *
 * NOTES:
 *      * Requires the terminal (Putty) to be set to UTF-8.
 *      * Does not function when running a screen session.
 */
#include "GoFish.h"
#include "./../CardCounter.h"
#include "./../Bank.h"
#include "./../Advertisement.h"
#include <signal.h>
#include <ncurses.h>
#include <time.h>
#include <vector>
#include <cstdlib>
#include <sstream>

using namespace std;

/* No Header file for this example driver artifact
 * function declaration here instead.
 */


// The gameDisplay object is global, because the static signal handler object
// needs to access the dynamic object.
display gameDisplay2;
game currentGame;
// using a stringstream rather than a string to make making the banner easier
stringstream messageString;
//Adding advertisement to game
Advertisement gfAds;
//importing the bank
extern Bank theBank;
//importing the card counter
extern CardCounter cardCounter;

//Constructor
GoFish::GoFish()
{
}

/**
* Displays the hand of the player on the screen.
*/
void GoFish::displayHand(std::vector<card> input)
{
	int displayCoordsX[] = {17,24,31,38,45,52,59,17,24,31,38,45,52};
	int displayCoordsY[] = {13,13,13,13,13,13,13,18,18,18,18,18,18};
	unsigned int x = 0;
	unsigned int y = input.size();
	/*
	messageString.str("");
	messageString << "Hand size:" << y ;
	gameDisplay2.bannerTop(messageString.str());
	*/
	
	gameDisplay2.drawBox(15,9,50,14,A_INVIS);
	for(; x < y; x++)
	{
		gameDisplay2.displayCard(displayCoordsX[x],displayCoordsY[x],input.at(x).getSuit(),input.at(x).getFace(), A_NORMAL);
	}
}

/**
* Displays the number of cards left in the deck.
*/
void GoFish::displayDeck(deck input)
{
	int d = input.getSize();
	/*
	messageString.str("");
	messageString << "Deck size: " << d ;
	gameDisplay2.bannerTop(messageString.str());
	*/
	//display Deck size
	stringstream stats;
	stats.str("");
	stats << "Deck size: " << d;
	mvprintw(2, 2, stats.str().c_str());
	
}

/*
* Draws the decks for computers.
*/
void GoFish::drawDeck(int comps)
{
	if(comps > 2)
	{
		GoFish::gameDisplay2.displayCard(5,8,0,0, COLOR_PAIR(4));
		mvprintw(6,5,"Computer 3");
	}
	if(comps > 1)
	{
		GoFish::gameDisplay2.displayCard(70,8,0,0, COLOR_PAIR(4));
		mvprintw(6,68,"Computer 2");
	}
	if(comps > 0)
	{
		GoFish::gameDisplay2.displayCard(35,4,0,0, COLOR_PAIR(4));
		mvprintw(2,32,"Computer 1");
	}
	
}

/*
* Draws the computer selection screen.
*/
void GoFish::drawSelection()
{
	GoFish::gameDisplay2.displayCard(10,5,1,1, A_BOLD);
	GoFish::gameDisplay2.displayCard(20,5,1,2, A_BOLD);
	GoFish::gameDisplay2.displayCard(30,5,1,3, A_BOLD);
}

/**
* Displays the scores of each player next to them.
*/
void GoFish::updateScore(int comps)
{
	const char* cstr3;
	const char* cstr2;
	const char* cstr1;
	const char* cstr;
	switch(comps)
	{
	case 3: 
		cstr3 = currentGame.getPlayer(3).getScore().c_str();
		mvprintw(7,5,cstr3); //Falls through to the next player
	case 2: 
		cstr2 = currentGame.getPlayer(2).getScore().c_str();
		mvprintw(7,58,cstr2);
	case 1: 
		cstr1 = currentGame.getPlayer(1).getScore().c_str();
		mvprintw(3,32,cstr1);
	default: 
		cstr = currentGame.getPlayer(0).getScore().c_str();
		mvprintw(12,40,cstr);
	}
}

/**
* Checks the game winning conditions to see if it has been won.
*/
bool GoFish::isGameOver()
{
	//checks to see if the game is over after each turn if all player hands and deck are empty
	int gameOverCounter=0;
	int totalPlayerCount=currentGame.getPlayerCount();

	if(theBank.bank<=0){
	  return true;
	}

	for(int i = 0; i < totalPlayerCount; i++)
	{
		if(currentGame.getPlayer(i).getHand().size()==0)
			gameOverCounter++;
	}
	if(gameOverCounter==totalPlayerCount && currentGame.getDeck().isEmpty()==true)
	{
		return true;
	}
	else 
		return false;
}

int GoFish::determineWinner()
{
  return Winner;
}

/*
 * This is the main function that starts the driver artifact.
 * This function demonstrates some of the abilities of the Display class
 */
int GoFish::startGoFish(GameTimer &timer)
{

	// various variable declarations
	char key;
	int numOfComps = 0;
	int coordX = 0;
	int coordY = 0;
	int gameState = 0;
	int cardSelected = 0;
	
	gameDisplay2.bannerTop("GoFish!");
	gameDisplay2.bannerTop("Select the number of computer players...");
	drawSelection();

	//opens advertisement text
	gfAds.openFile("advertisement.txt");

	gameDisplay2.bannerTop("Place a bet to win each round. Please enter a value (0 if no bet), then hit enter.");	
	gameDisplay2.updateScreen();
	theBank.getBet();

	for(;;)
	{
	  char quit;
	  mvprintw(15,15, "Type q to go back to main menu");
	  cin >> quit;
	  
	  key = gameDisplay2.captureInput();
	  coordX = gameDisplay2.getMouseEventX();
	  coordY = gameDisplay2.getMouseEventY();
		
	drawSelection();

		if(quit == 'q')
		  return 0;

		if(coordX >= 10 && coordX <= 15 && coordY >= 5 && coordY <= 9)
		{
			gameDisplay2.bannerBottom("1 Computer selected.");
			numOfComps = 1;
			break;
		}
		else if(coordX >= 20 && coordX <= 25 && coordY >= 5 && coordY <= 9)
		{
			gameDisplay2.bannerBottom("2 Computers selected.");
			numOfComps = 2;
			break;
		}
		else if(coordX >= 30 && coordX <= 35 && coordY >= 5 && coordY <= 9)
		{
			gameDisplay2.bannerBottom("3 Computers selected.");
			numOfComps = 3;
			break;
		}
		
	}

	//Creates the computer players on the screen.
	//gameDisplay2.bannerTop("GoFish");
	gameDisplay2.eraseBox(2,2,40,10);
	player player1("Player 1",12,40);
	player player2("Computer 1",35,4,7,5);
	player player3("Computer 2",70,8,7,68);
	player player4("Computer 3",5,8,3,32);
	mvprintw(12,32,"(You)");
	mvprintw(12,40,"Score: 0");
	currentGame.addPlayer(player1);

	if(numOfComps > 2)
	{
		currentGame.addPlayer(player4); //add player to game
	}
	if(numOfComps > 1)
	{
		currentGame.addPlayer(player3); //add player to game
	}
	if(numOfComps > 0)
	{
		currentGame.addPlayer(player2); //add player to game
	}
	drawDeck(numOfComps);
	currentGame.createGame(); //deal out the cards and perform any other configuration
	displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
	updateScore(numOfComps); //update the score in case any pairs off the bat

	for (;;) 
	{
		bool gameOver = false;
		while(!gameOver)
		{
		  drawDeck(numOfComps);
			key = gameDisplay2.captureInput();
			coordX = gameDisplay2.getMouseEventX();
			coordY = gameDisplay2.getMouseEventY();

			//show stats in game
			stringstream stats;
			stats.str("");
			stats << "Bank: $" << theBank.bank;
			mvprintw(22, 2, stats.str().c_str());
			stats.str("");
			double gfTime = 0;
			gfTime += timer.endTimer();
			stats << "Time Spent Playing GoFish: " << (int)gfTime/60 << "m " << (int)gfTime%60 << "s";
			mvprintw(23, 2, stats.str().c_str());
			stats.str("");
			stats << "# cards played in GoFish: " << cardCounter.goFishCardCount;
			mvprintw(24, 2,stats.str().c_str());
			gameDisplay2.updateScreen();

			//The Player's turn
			if(gameState == 0) //wait for user input for card selection
			{
				cardSelected = currentGame.getPlayer(0).coordsToCard(coordX,coordY); //see if player clicked on card in hand
				if(currentGame.getPlayer(0).getHand().size() == 0) //Check if hand is empty first
				{
					gameDisplay2.bannerBottom("Go Fish!");
					if(currentGame.getDeck().isEmpty() == false)
						currentGame.addCard( currentGame.drawCard(),0 ); //draw a card
					gameState = 2; //Go to computer's turn
					displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
					updateScore(numOfComps); //update the score in case any pairs off the bat
					cardSelected = -1; //invalidate card selection
				}
				else if(cardSelected > -1 && cardSelected < 14) //Card is selected
				{
					char buffer[30];
					sprintf(buffer, "%d selected. Ask a player.", cardSelected);
					gameDisplay2.bannerBottom(buffer); //display the card selected
					gameState = 1;
				}
				else
				{
					gameDisplay2.bannerBottom("Select a card.");
					cardSelected = -1;
				}

			}
			else if(gameState == 1) //The user must now select a computer to ask
			{
				//Checks if the hand size is empty but the game has not been won yet, can still draw cards
				if(currentGame.getPlayer(0).getHand().size() == 0 && currentGame.getDeck().isEmpty() == false && isGameOver() == false)
				{
				  
				  gameDisplay2.bannerBottom("Go Fish!");
				  if(currentGame.getDeck().isEmpty() == false)
				    currentGame.addCard( currentGame.drawCard(),0 );

				  displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
				  updateScore(numOfComps); //update the score in case any pairs off the bat
				  cardSelected = -1;
				  gameState = 2;
				}

				//Computer 3's deck selected
				else if(coordX >= 5 && coordX <= 10 && coordY >= 8 && coordY <= 12)
				{
					if(numOfComps == 3) //Check if computer exists
					{
						if(currentGame.getPlayer(3).haveCard(cardSelected) == true) //Check if computer has card
						{
							gameDisplay2.bannerBottom("Computer 3");
							card::card c = currentGame.takeCard(cardSelected,3);
							currentGame.addCard( c,0 );
							cardSelected = -1;
							gameState = 2;
							displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
							updateScore(numOfComps); //update the score in case any pairs off the bat
							theBank.winBet();
						}
						else //Otherwise draw from deck
						{
							gameDisplay2.bannerBottom("Go Fish!");
							if(currentGame.getDeck().isEmpty() == false)
								currentGame.addCard( currentGame.drawCard(),0 );
							displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
							updateScore(numOfComps); //update the score in case any pairs off the bat
							cardSelected = -1;
							gameState = 2;
							theBank.lossBet();
						}
						gameOver = isGameOver();
						if(gameOver == true) {
						  if(0 == currentGame.highestScore())
						    {
						      Winner = 1;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"You WON!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						  else
						    {
						      Winner = 0;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"Sorry. You LOST!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						}
					}
					else //Does not exist
					{
						cardSelected = -1;
						gameState = 0;
					}
				}

				//Computer 1's deck selected
				else if(coordX >= 35 && coordX <= 40 && coordY >= 4 && coordY <= 8)
				{
					if(currentGame.getPlayer(1).haveCard(cardSelected) == true) //Check if computer has card
					{
						gameDisplay2.bannerBottom("Computer 1");
						card::card c = currentGame.takeCard(cardSelected,1);
						currentGame.addCard( c,0 );
						cardSelected = -1;
						gameState = 2;
						displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
						updateScore(numOfComps); //update the score in case any pairs off the bat
						theBank.winBet();
					}
					else //Otherwise draw from deck
					{
						gameDisplay2.bannerBottom("Go Fish!");
						if(currentGame.getDeck().isEmpty() == false)
							currentGame.addCard( currentGame.drawCard(),0 );
						displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
						updateScore(numOfComps); //update the score in case any pairs off the bat
						cardSelected = -1;
						gameState = 2;
						theBank.lossBet();
					}
					gameOver = isGameOver();
					if(gameOver == true) {
						  if(0 == currentGame.highestScore())
						    {
						      Winner = 1;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"You WON!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						  else
						    {
						      Winner = 0;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"Sorry. You LOST!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						}
				}

				//Computer 2's deck selected
				else if(coordX >= 70 && coordX <= 75 && coordY >= 8 && coordY <= 12) //Computer 2's deck selected
				{
					if(numOfComps > 1) //Check if computer exists
					{
						if(currentGame.getPlayer(2).haveCard(cardSelected) == true) //Check if computer has card
						{
							gameDisplay2.bannerBottom("Computer 2");
							card::card c = currentGame.takeCard(cardSelected,2);
							currentGame.addCard( c,0 );
							cardSelected = -1;
							gameState = 2;
							displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
							updateScore(numOfComps); //update the score in case any pairs off the bat
							theBank.winBet();
						}
						else //Otherwise draw from deck
						{
							gameDisplay2.bannerBottom("Go Fish!");
							if(currentGame.getDeck().isEmpty() == false)
								currentGame.addCard( currentGame.drawCard(),0 );
							displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
							updateScore(numOfComps); //update the score in case any pairs off the bat
							cardSelected = -1;
							gameState = 2;
							theBank.lossBet();
						}
						gameOver = isGameOver();
					if(gameOver == true) {
						  if(0 == currentGame.highestScore())
						    {
						      Winner = 1;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"You WON!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						  else
						    {
						      Winner = 0;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"Sorry. You LOST!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						}
					}
					else //Does not exist
					{
						cardSelected = -1;
						gameState = 0;
					}
				}

				else if(coordY < 13) //Coordinates not in playing area, unselect card and start over
				{
					cardSelected = -1;
					gameState = 0;
				}
			}

			//Computer's turn
			else if(gameState == 2)
			{
				/*AI algorithm
				* Iterate through the computer list and randomly select a card from hand and then randomly select a computer to play it on.
				*/
				int i = 1;
				for(; i <= numOfComps; i++) //Loop through computers
				{
					if(currentGame.getPlayer(i).getHand().size() > 0) //Make sure has something in hand
					{
						int computerPlayerFaceVal = currentGame.getPlayer(i).getRandomCard().getFace();//get random card from hand
						srand(time(NULL)); //Seed the random number generator
						int randPlayerNumber = rand()%(numOfComps);
						while(randPlayerNumber == i)
						{
							randPlayerNumber = rand()%(numOfComps); //Make sure computer doesn't ask itself
						}
						if(currentGame.getPlayer(randPlayerNumber).haveCard(computerPlayerFaceVal) == true) //Has card
						{
							currentGame.addCard( currentGame.takeCard(computerPlayerFaceVal,randPlayerNumber),i ); //Take card from player
						}
						else //Otherwise GoFish
						{
							if(currentGame.getDeck().isEmpty() == false)
								currentGame.addCard( currentGame.drawCard(),i );
						}
					}
					else //Otherwise GoFish
					{
						if(currentGame.getDeck().isEmpty() == false)
							currentGame.addCard( currentGame.drawCard(),i );
					}
					gameOver = isGameOver();
					if(gameOver == true) {
						  if(0 == currentGame.highestScore())
						    {
						      Winner = 1;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"You WON!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						  else
						    {
						      Winner = 0;
						      gameDisplay2.eraseBox(0,2,80,40);
						      mvprintw(10,10,"Sorry. You LOST!");
						      gameDisplay2.updateScreen();
						      sleep(3);
						      break;
						    }
						}
				}
				  
				displayHand(currentGame.getPlayer(0).getHand()); //display the new hand
				updateScore(numOfComps); //update the score in case any pairs off the bat
				gameState = 0;
				cardSelected = -1;
				
				//advertisement file reading sequentially
				gameDisplay2.bannerTop(gfAds.getAdvert());
				//display deck size:
				//displayDeck(currentGame.getDeck());

			}
		}

		return 0;
	}
}
