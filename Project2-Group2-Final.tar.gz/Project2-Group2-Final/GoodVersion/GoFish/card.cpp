/*
 * Card.cpp
 *
 *  Created on: Oct 11, 2012
 *      Author: Trevor Elkins
 */

#include "card.h"

//Constructor
card::card(int suit, int face)
{
	card::_suit = suit;
	card::_face = face;
}

//Constructor
card::card()
{
	
}

/**
 * Returns the value for suit.
 */
int card::getSuit()
{
	return card::_suit;
}

/**
 * Returns the value for face.
 */
int card::getFace()
{
	return card::_face;
}
