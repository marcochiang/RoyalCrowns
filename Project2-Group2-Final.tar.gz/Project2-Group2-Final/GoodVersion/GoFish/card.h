/*
 * Card.h
 *
 *  Created on: Oct 11, 2012
 *      Author: Trevor Elkins
 */

#ifndef CARD_H_
#define CARD_H_

class card {
public:
	card(int suit, int face);
	card();
	int getSuit();
	int getFace();
	enum face_values {ONE=1,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,JACK,QUEEN,KING,ACE};
	enum suit_values {HEART=1,DIAMOND,SPADE,CLUBS};

private:
	int _suit, _face;
};

#endif /* CARD_H_ */
