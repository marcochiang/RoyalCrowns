/*
 * Deck.h
 *
 *  Created on: Oct 11, 2012
 *      Author: Trevor Elkins
 */

#ifndef DECK_H_
#define DECK_H_
#include <vector>
#include "card.h"

class deck
{
public:
	deck();
	bool isEmpty();
	void newDeck();
	card dealCard();
	int getSize();
	void displayHand(int start);

private:
	std::vector<card> _deck;
};

#endif /* DECK_H_ */
