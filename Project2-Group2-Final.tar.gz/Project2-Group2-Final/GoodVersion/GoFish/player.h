/*
 * Player.h
 *
 *  Created on: Oct 20, 2012
 *      Author: Trevor Elkins
 */

#ifndef PLAYER_H_
#define PLAYER_H_

#include <vector>
#include <string>
#include "card.h"
#include "deck.h"
#include <stdlib.h>

class player
{

private:
	std::vector<card> _hand;
	int _score;
	int _xCoord;
	int _yCoord;
	int _xScore;
	int _yScore;
	std::string _name;

public:
	player(std::string name, int x, int y, int scoreX, int scoreY);
	player(std::string name, int scoreX, int scoreY);
	void addCard(card card);
	bool haveCard(int n);
	card::card takeCard(int faceVal);
	int coordsToCard(int x, int y);
	bool hasDuplicate();
	std::string getName();
	std::string getScore();
	int getScoreVal();
	std::vector<card> getHand();
	void setHand(std::vector<card> set);
	card::card getRandomCard();
};


#endif /* PLAYER_H_ */
