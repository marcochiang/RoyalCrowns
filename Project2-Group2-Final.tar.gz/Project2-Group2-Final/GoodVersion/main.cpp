
#include "display.h"
#include "menu.h"
#include <signal.h>
#include <ncurses.h>
#include <cstdlib>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include "Hearts/HeartsGame.h"
#include "GoFish/GoFish.h"
#include "BlackJack/BlackJack.h"
#include <stdio.h>
#include <stdlib.h>
#include "GameTimer.h"
#include "CardCounter.h"
#include "Bank.h"
#include "Advertisement.h"
using namespace std;

/* No Header file for this example driver artifact
 * function declaration here instead.
 */
 // Signal Subroutine for Window Resize
 static void detectResize (int sig);
 // stub artifact for what the game does when the screen resizes
 void stub_PrintResize(void);

//this struct holds location values for the different option boxes

typedef struct MenuOptions{
    int heartsX;
    int heartsY;
    int goFishX;
	int goFishY;
	int blackJackX;
	int blackJackY;
	int quitX;
	int quitY;
	int boxWidth;
	int boxHeight;
}MenuOptions;

/*
//this struct holds the card counter for each game
typedef struct CardCounter{
	int goFishCount;
	int blackJackCount;
	int heartsCount;
}CardCounter;
*/

// The gameDisplay object is global, because the static signal handler object
// needs to access the dynamic object.
display gameDisplay;

GameTimer timer;
Bank theBank;
Advertisement ads;
CardCounter cardCounter;

// Title and advertisement display
stringstream Title;

stringstream Ad;

/*
//returns bet provided via user input. Keeps asking until valid and bet is less than bank
int getBet(){
	string userBet = "";
	int theBet;
	cin >> userBet;
	while(1){
		if(!sscanf(userBet.c_str(), "%d", &theBet)){
		gameDisplay.bannerTop("Please enter a number");
		gameDisplay.updateScreen();	
		}
		else{
			if(theBet >= theBank){
				gameDisplay.bannerTop("Please enter an amount less than your current bank.");
				gameDisplay.updateScreen();
			}
			else{
				stringstream messageString;
				messageString.str("");
				messageString << "You have bet $" << userBet << " on Hearts";
				gameDisplay.bannerTop(messageString.str());
				gameDisplay.updateScreen();
				sleep(2);
				break;
			}
		}	
		cin >> userBet;	
	}

	return atoi(userBet.c_str());
}
*/

//displays option button with text at location and fills in the MenuOptions struct values
void displayOption(int xPosition, int yPosition, string option, MenuOptions &menu){

	gameDisplay.drawBox(xPosition,yPosition,menu.boxWidth,menu.boxHeight, A_NORMAL);
	if(option == "Hearts"){
		menu.heartsX = xPosition;
		menu.heartsY = yPosition;
		mvprintw(yPosition+1,xPosition+1, "Hearts");			//Custom Edit
	}
	else if(option == "Go Fish"){
		menu.goFishX = xPosition;
		menu.goFishY = yPosition;		
		mvprintw(yPosition+1,xPosition+1, "Go Fish");			//Custom Edit
	}
	else if(option == "Blackjack"){
		menu.blackJackX = xPosition;
		menu.blackJackY = yPosition;
		mvprintw(yPosition+1,xPosition+1, "BlackJack");		//Custom Edit
	}
	else if(option == "Quit"){
		menu.quitX = xPosition;
		menu.quitY = yPosition;
		mvprintw(yPosition+1,xPosition+1, "Exit");			//Custom Edit
	}

}

/*
 * This is the main function that starts the driver artifact.
 * This function demonstrates some of the abilities of the Display class
 */
int main(int argc, char* argv[])
{

	//cardCounter.goFishCardCount = 0;
	//cardCounter.blackJackCardCount = 0;
	//cardCounter.heartsCardCount = 0;

	MenuOptions options;
	options.boxWidth = 11;
	options.boxHeight = 4;
	// enable a interrupt triggered on a window resize
	signal(SIGWINCH, detectResize); // enable the window resize signal


	int key;
	int coordX;
	int coordY;

	//advertisement file reading
	ads.openFile("advertisement.txt");
	gameDisplay.bannerBottom(ads.getAdvert());

	for(;;){
		Title.str("");
		Title << "Sunnyside Suites Casino";
		gameDisplay.bannerTop(Title.str());
/*commented for trying other ads scheme
		Ad.str("");
		Ad << "Advertisement Test";
		gameDisplay.bannerBottom(Ad.str());
*/
		gameDisplay.bannerBottom(ads.advert);
		gameDisplay.updateScreen();
		// Statistics display (Placeholders for now, may need to use structs to do this part correctly)
		stringstream stats;
		stats.str("");
		stats << "Bank: $" << theBank.bank;
		mvprintw(5, 2, stats.str().c_str());
		stats.str("");
		stats << "Time Spent Playing Hearts: " << (int)timer.heartsTimer/60 << "m " << (int)timer.heartsTimer%60 << "s";
mvprintw(6, 2, stats.str().c_str());
		stats.str("");
		stats << "Time Spent Playing BlackJack: " << (int)timer.blackJackTimer/60 << "m " << (int)timer.blackJackTimer%60 << "s";
		mvprintw(7, 2, stats.str().c_str());
		stats.str("");
		stats << "Time Spent Playing GoFish: " << (int)timer.goFishTimer/60 << "m " << (int)timer.goFishTimer%60 << "s";
		mvprintw(8, 2, stats.str().c_str());
		stats.str("");
		stats << "# cards played in Hearts: " << cardCounter.heartsCardCount;
		mvprintw(9, 2, stats.str().c_str());
		stats.str("");
		stats << "# cards played in BlackJack: " << cardCounter.blackJackCardCount;
		mvprintw(10, 2, stats.str().c_str());
		stats.str("");
		stats << "# cards played in GoFish: " << cardCounter.goFishCardCount;
		mvprintw(11, 2,stats.str().c_str());

		//create menu boxes here
		displayOption(45, 1, "Blackjack", options);
		displayOption(45, 6, "Go Fish", options);
		displayOption(45, 11, "Hearts", options);
		displayOption(45, 16, "Quit", options);
		coordX = 0;
		coordY = 0;
		key = gameDisplay.captureInput();
		if (key == -1) {
			coordX = gameDisplay.getMouseEventX();
			coordY = gameDisplay.getMouseEventY();
		}

		//Blackjack is clicked
		if(coordX < (options.blackJackX+options.boxWidth) && coordX > options.blackJackX
		&& coordY < (options.blackJackY+options.boxHeight) && coordY > options.blackJackY){
			gameDisplay.bannerTop("You've chosen Blackjack");
			//TODO: write code to step into Blackjack
			BlackJack BJ;
			BJ.startBJ();
			//Advertisements			
			gameDisplay.bannerBottom(ads.getAdvert());
			gameDisplay.updateScreen();		
		}

		//go fish is clicked
		if(coordX < (options.goFishX+options.boxWidth) && coordX > options.goFishX
		&& coordY < (options.goFishY+options.boxHeight) && coordY > options.goFishY){
			gameDisplay.bannerTop("You've chosen Go Fish");
			//TODO: write code to step into go fish game
			theBank.getBet();
			int wholeGameBet = 2*(theBank.bet);
			theBank.bank -= theBank.bet;
			timer.startTimer();
			GoFish goFishGame;
			gameDisplay.bannerBottom(ads.getAdvert());		
			gameDisplay.updateScreen();		
			goFishGame.startGoFish(timer);
			timer.goFishTimer += timer.endTimer();

			if(goFishGame.determineWinner()==1)
			  theBank.bank += wholeGameBet;
			else
			  theBank.bank -= wholeGameBet;
		}

		//Hearts is clicked
		if(coordX < (options.heartsX+options.boxWidth) && coordX > options.heartsX
		&& coordY < (options.heartsY+options.boxHeight) && coordY > options.heartsY){
			
			gameDisplay.bannerTop("How much would you like to bet on Hearts? Please enter a value, then hit enter.");	
			gameDisplay.updateScreen();		
			theBank.getBet();
			int wholeGameBet = 2*(theBank.bet);	
			theBank.bank -= theBank.bet;	
 			HeartsGame heartsGame;
 			heartsGame.setupGame();
			timer.startTimer();
 			while(!heartsGame.isGameOver()){
 				heartsGame.testGame(cardCounter);
 			}
			timer.heartsTimer += timer.endTimer();
 			if(theBank.bank <= 0){
				break;
			}
			if(heartsGame.determineWinner()){
				theBank.bank += wholeGameBet;
			}
			gameDisplay.bannerBottom(ads.getAdvert());
			gameDisplay.updateScreen();
		}	
		
		//Quit is clicked
		if(coordX < (options.quitX+options.boxWidth) && coordX > options.quitX
		&& coordY < (options.quitY+options.boxHeight) && coordY > options.quitY){
			gameDisplay.bannerTop("You've chosen to quit");
			break;
		}
		gameDisplay.eraseBox(0,0,gameDisplay.getCols(), gameDisplay.getLines());	
		if(theBank.bank<=0){
			gameDisplay.bannerTop("You've lost all your money! Come back another time and play again!");
			gameDisplay.updateScreen();
			sleep(3);
			break;
		}	
	}

//TODO: if after quit we want to display something or do anything else beside exit, do it here
	ads.closeFile();

// You can uncomment and change the colors for various cards here
//    init_pair(1, COLOR_CYAN, COLOR_BLACK); // for card outline
//    init_pair(2, COLOR_BLUE, COLOR_BLACK); // for spades and clubs
//    init_pair(3, COLOR_RED, COLOR_BLACK);  // for hearts and diamonds
//    init_pair(4, COLOR_GREEN, COLOR_BLACK); // for turned over card
//    init_pair(5, COLOR_GREEN, COLOR_BLACK); // for box drawing
//    init_pair(6, COLOR_GREEN, COLOR_BLACK); // for banner display

	return 0;
}

/*
 * This is the interrupt service routine called when the resize screen
 * signal is captured.
 */
 void detectResize(int sig) {
	 //update the display class information with the new window size
     gameDisplay.handleResize(sig);
	 //re-enable the interrupt for a window resize
      signal(SIGWINCH, detectResize);
	  /*INSERT YOUR OWN SCREEN UPDATE CODE instead of stub_PrintResize*/
	  stub_PrintResize();
  }

/*
 * This is a simple stub that should be replaced with what the game does
 * when the screen resizes.
 */
 void stub_PrintResize(void) {
	  //gets the new screen size
	  gameDisplay.~display();
	  gameDisplay.updateScreen();
	  int cols = gameDisplay.getCols();
	  int lines = gameDisplay.getLines();
	 //setups a message stream
	 stringstream messageString;
	 messageString << "Terminal is " << cols << "x" << lines;
	 // prints out the information of the new screen size in a top banner
	 gameDisplay.bannerTop(messageString.str());
 }
